# -*- coding: utf-8 -*-
"""
Windows 10 / 11 个人操作系统（及 Windows Server 2016 及以上版本）安全基线检查引擎

检查项依据：《Windows 10/11 个人操作系统测评项：检测命令与预期回显》
共 6 个控制域、22 个子项：
    - 身份鉴别   IA-a ~ IA-d  (4 项)
    - 访问控制   AC-a ~ AC-g  (7 项)
    - 安全审计   AU-a ~ AU-d  (4 项)
    - 入侵防范   IP-a ~ IP-e  (5 项)
    - 恶意代码防范 MC-a      (1 项)
    - 可信验证   TV-a         (1 项)

支持 Windows 10 / Windows 11 / Windows Server 2016 及以上版本 差异化检测：
通过构造参数 target_os（"win10" / "win11" / "win_server"）区分。
具体实现代码与判定口径因版本而异（参考文件多处指明“新版 Windows”与“旧版”实现不同，
例如 TV-a 的 VBS/Credential Guard、IP-d 的补丁构建基线、IP-e 的 SYN 防护），
Windows Server 在上述项及若干注册表/产品名口径上与客户端存在实质差异，必须分别处理，不可一概而论。

每项检查返回结构化结果（通过/不通过/警告/信息/错误 + 实际值 + 期望 + 详情 + 整改建议）。
基于 Windows 注册表、组策略(secedit)、PowerShell(CIM/WMI)、auditpol/wevtutil/netsh 等系统接口核查。

判定口径（verify_type）：
    - 可直接核验：系统能直接返回配置或状态，按关键字段判定
    - 需结合基线：命令能返回现状，但需与已批准的安全基线/白名单比对
    - 需补充证据：本机无法证明管理过程/外部平台能力，需补充制度或受控测试记录

Author: Zero Two Team
"""

import json
import os
import platform
import re
import subprocess
import tempfile
import traceback
try:
    import winreg  # 仅 Windows 平台可用；Linux Web 版仅需复用数据模型，做跨平台保护
except ImportError:  # pragma: no cover - 非 Windows 环境
    winreg = None
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Tuple


# ============================================================
# 常用初筛参考值（仅用于初筛，不替代已批准基线/等保标准）
# 参考文件明确指出“常用参考值仅用于初筛，不替代项目适用的等级保护标准”。
# ============================================================
SCREEN_MIN_PW_LEN = 8            # 最小口令长度（位）
SCREEN_MAX_PW_AGE_DAYS = 90      # 最长口令使用期（天）
SCREEN_PW_HISTORY = 5            # 强制口令历史（次）
SCREEN_LOCKOUT_THRESHOLD = 5     # 账户锁定阈值（次）
SCREEN_LOCKOUT_DURATION_MIN = 30  # 账户锁定时间（分钟）
SCREEN_LOCKOUT_RESET_MIN = 15    # 计数器重置时间（分钟）
SCREEN_SCREENSAVER_TIMEOUT_SEC = 900  # 屏幕保护等待（秒）= 15 分钟
STALE_ACCOUNT_DAYS = 90          # 疑似闲置账户判定天数

# 各 OS 最低补丁构建基线（初筛参考；Win10 最高支持构建约 19045，Win11 自 22000 起）
MIN_BUILD_WIN10 = 19045
MIN_BUILD_WIN11 = 22000
# Windows Server 按具体版本区分（2016=14393 / 2019=17763 / 2022=20348），
# 通用下限取 Server 2016，避免把 Server 误判为低于 Win10/Win11 桌面基线。
MIN_BUILD_WIN_SERVER = 14393
SERVER_MIN_BUILD = {
    "Windows Server 2016": 14393,
    "Windows Server 2019": 17763,
    "Windows Server 2022": 20348,
}


def detect_os_display_name() -> str:
    """返回本机操作系统展示名（含 Windows Server 区分；供 UI 系统信息卡片使用）。

    客户端 1607（build 14393）与 Server 2016 同构建号，必须借助 ProductType 区分。
    """
    release = platform.version()
    try:
        build_num = int(release.split(".")[-1])
    except (ValueError, IndexError):
        return f"Windows ({release})"
    if build_num >= 22000:
        return "Windows 11"
    try:
        out, _, _ = _run_cmd(
            'powershell -NoProfile -Command '
            '"(Get-CimInstance Win32_OperatingSystem).ProductType"')
        if out.strip() in ("2", "3"):
            pn, _, _ = _run_cmd(
                'powershell -NoProfile -Command "(Get-ComputerInfo).WindowsProductName"')
            pn = pn.strip()
            return pn or "Windows Server 2016及以上版本"
    except Exception:
        pass
    return "Windows 10"


# ============================================================
# 数据模型
# ============================================================

class CheckStatus(Enum):
    """检查结果状态枚举"""
    PASS = "通过"        # 完全符合要求
    FAIL = "不通过"      # 不符合要求（高风险）
    WARN = "警告"        # 部分符合或需关注/需结合基线
    INFO = "信息"        # 仅记录，需补充证据/人工核实
    ERROR = "错误"       # 检查过程出错


@dataclass
class CheckItem:
    """
    单项检查条目定义（与参考文件 22 子项一一对应）

    Attributes:
        id: 检查项唯一编号（IA-a / AC-b / TV-a 等）
        name: 检查项名称
        category: 所属控制域（身份鉴别/访问控制/安全审计/入侵防范/恶意代码防范/可信验证）
        description: 检查项详细描述
        risk_level: 风险等级 ("高" | "中" | "低")
        remediation: 整改建议
        verify_type: 判定口径（可直接核验 / 需结合基线 / 需补充证据）
        win10_compatible: 是否适用于 Windows 10
        win11_compatible: 是否适用于 Windows 11
        win_server_compatible: 是否适用于 Windows Server 2016 及以上版本
    """
    id: str
    name: str
    category: str
    description: str = ""
    risk_level: str = "中"
    remediation: str = ""
    verify_type: str = "可直接核验"
    win10_compatible: bool = True
    win11_compatible: bool = True
    win_server_compatible: bool = True


@dataclass
class CheckResult:
    """
    单项检查执行结果
    """
    item: CheckItem
    status: CheckStatus
    actual_value: str = ""
    expected_value: str = ""
    detail: str = ""
    evidence: List[str] = field(default_factory=list)
    os_target: str = ""
    timestamp: str = field(default_factory=lambda: datetime.now().strftime("%Y-%m-%d %H:%M:%S"))

    def to_dict(self) -> dict:
        """序列化为字典"""
        return {
            "id": self.item.id,
            "name": self.item.name,
            "category": self.item.category,
            "status": self.status.value,
            "risk_level": self.item.risk_level,
            "verify_type": self.item.verify_type,
            "actual_value": self.actual_value,
            "expected_value": self.expected_value,
            "detail": self.detail,
            "remediation": self.item.remediation,
            "evidence": self.evidence,
            "os_target": self.os_target,
            "timestamp": self.timestamp,
        }


@dataclass
class SystemInfo:
    """系统基本信息"""
    hostname: str = ""
    os_version: str = ""       # "Windows 10" / "Windows 11" / "Windows Server 2016及以上版本"(或具体产品名)
    os_build: str = ""         # 版本号如 22631
    architecture: str = ""     # amd64 等
    username: str = ""         # 当前用户
    ip_addresses: List[str] = field(default_factory=list)
    target_os: str = ""        # win10 / win11 / win_server


# ============================================================
# Windows 注册表 / 命令工具函数
# ============================================================

def _read_reg_value(hive_key: int, sub_key: str, value_name: str,
                    default: Any = None) -> Tuple[Any, bool]:
    """读取注册表值，返回 (值, 是否成功)"""
    try:
        key = winreg.OpenKey(hive_key, sub_key, 0, winreg.KEY_READ)
        value, _ = winreg.QueryValueEx(key, value_name)
        winreg.CloseKey(key)
        return value, True
    except (FileNotFoundError, OSError, PermissionError):
        return default, False


def _reg_value_int(hive_key: int, sub_key: str, value_name: str,
                   default: int = 0) -> int:
    """读取注册表整型值（读取失败或类型不符返回 default）"""
    val, ok = _read_reg_value(hive_key, sub_key, value_name)
    if ok and isinstance(val, int):
        return val
    return default


def _export_reg_key(hive_key: int, sub_key: str, output_path: str) -> bool:
    """导出注册表子键到 .reg 文件作为证据"""
    hive_names = {
        winreg.HKEY_LOCAL_MACHINE: "HKEY_LOCAL_MACHINE",
        winreg.HKEY_CURRENT_USER: "HKEY_CURRENT_USER",
        winreg.HKEY_USERS: "HKEY_USERS",
        winreg.HKEY_CLASSES_ROOT: "HKEY_CLASSES_ROOT",
    }
    hive_name = hive_names.get(hive_key, "HKLM")
    full_path = f"{hive_name}\\{sub_key}"
    try:
        result = subprocess.run(
            ["reg", "export", full_path, output_path, "/y"],
            capture_output=True, text=True, errors="replace", timeout=30,
            creationflags=subprocess.CREATE_NO_WINDOW
        )
        return result.returncode == 0
    except Exception:
        return False


def _run_cmd(cmd: str, timeout: int = 30) -> Tuple[str, str, int]:
    """
    执行 shell 命令并捕获输出，返回 (stdout, stderr, returncode)
    cmd 中的管道符由 cmd.exe 解释。
    """
    try:
        result = subprocess.run(
            cmd, shell=True, capture_output=True, text=True, errors="replace",
            timeout=timeout, creationflags=subprocess.CREATE_NO_WINDOW
        )
        return result.stdout.strip(), result.stderr.strip(), result.returncode
    except subprocess.TimeoutExpired:
        return "", "命令超时", -1
    except Exception as e:
        return "", str(e), -1


def _run_powershell(script: str, timeout: int = 60) -> Tuple[str, str, int]:
    """
    将 PowerShell 脚本写入临时 .ps1 文件并以 -File 方式执行，规避命令行引号转义问题。
    返回 (stdout, stderr, returncode)
    """
    import tempfile as _tf
    fd, path = _tf.mkstemp(suffix=".ps1", prefix="zt_")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(script + "\n")
        result = subprocess.run(
            ["powershell", "-NoProfile", "-NonInteractive", "-ExecutionPolicy",
             "Bypass", "-File", path],
            capture_output=True, text=True, errors="replace", timeout=timeout,
            creationflags=subprocess.CREATE_NO_WINDOW
        )
        return result.stdout.strip(), result.stderr.strip(), result.returncode
    except subprocess.TimeoutExpired:
        return "", "PowerShell 命令超时", -1
    except Exception as e:
        return "", str(e), -1
    finally:
        try:
            os.unlink(path)
        except OSError:
            pass


def _ps_json(script: str, timeout: int = 60) -> Tuple[Any, str]:
    """
    执行 PowerShell 脚本并将结果通过 ConvertTo-Json 解析为 Python 对象。
    返回 (python_obj, error_msg)。脚本末尾会自动追加 ConvertTo-Json。
    """
    full = script + " | ConvertTo-Json -Compress -Depth 4"
    out, err, rc = _run_powershell(full, timeout)
    if rc != 0 or not out:
        return None, (err or "无输出")
    try:
        return json.loads(out), ""
    except json.JSONDecodeError:
        return None, f"JSON 解析失败: {out[:200]}"


# ============================================================
# 主检查器类
# ============================================================

class BaselineChecker:
    """
    Windows 10/11 个人操作系统（及 Windows Server 2016 及以上版本）安全基线检查引擎

    执行 22 项基线检查，返回完整的检查结果集。支持 Win10/Win11/WinServer 差异化检测。
    """

    def __init__(self, target_os: str = ""):
        """
        Args:
            target_os: 目标操作系统版本 ("win10" / "win11" / "win_server"，或空=自动检测)
        """
        self.target_os = target_os or self._detect_os_version()
        self.system_info = self._collect_system_info()
        self.system_info.target_os = self.target_os
        self.check_items = self._build_check_items()
        self._results: List[CheckResult] = []
        self.evidence_dir: str = ""
        self._secedit_cache: Optional[Dict[str, str]] = None

    # ----------------------------------------------------------
    # OS 版本
    # ----------------------------------------------------------
    @staticmethod
    def _detect_os_version() -> str:
        """自动检测当前操作系统版本（含 Windows Server 区分）"""
        release = platform.version()  # 如 "10.0.22631"
        try:
            build_num = int(release.split(".")[-1])
        except (ValueError, IndexError):
            return "win10"
        # 服务器产品（ProductType=2 域控 / 3 服务器）按 Server 处理；
        # 注意：14393 既是 Win10 1607 也是 Server 2016，必须借助 ProductType 区分。
        try:
            out, _, _ = _run_cmd(
                'powershell -NoProfile -Command '
                '"(Get-CimInstance Win32_OperatingSystem).ProductType"')
            if out.strip() in ("2", "3"):
                return "win_server"
        except Exception:
            pass
        return "win11" if build_num >= 22000 else "win10"

    @property
    def is_win11(self) -> bool:
        return self.target_os == "win11"

    @property
    def is_win_server(self) -> bool:
        """是否为 Windows Server 2016 及以上版本目标"""
        return self.target_os == "win_server"

    def _collect_system_info(self) -> SystemInfo:
        info = SystemInfo()
        info.hostname = os.environ.get("COMPUTERNAME", "未知")
        info.username = os.environ.get("USERNAME", "未知")
        info.architecture = platform.machine()
        build_str = platform.version()
        info.os_build = build_str.split(".")[-1] if "." in build_str else build_str
        if self.target_os == "win_server":
            # 优先读取真实产品名；无法读取时回退到规范称谓
            prod, _, _ = _run_cmd(
                'powershell -NoProfile -Command "(Get-ComputerInfo).WindowsProductName"')
            prod = prod.strip()
            info.os_version = prod or "Windows Server 2016及以上版本"
        else:
            try:
                if int(info.os_build) >= 22000:
                    info.os_version = "Windows 11"
                else:
                    info.os_version = "Windows 10"
            except ValueError:
                info.os_version = f"Windows ({build_str})"
        stdout, _, _ = _run_cmd('ipconfig | findstr /i "IPv4"')
        for line in stdout.splitlines():
            if ":" in line:
                ip = line.split(":")[-1].strip()
                if ip and ip != "0.0.0.0":
                    info.ip_addresses.append(ip)
        return info

    # ----------------------------------------------------------
    # 检查项定义（22 项，6 域）
    # ----------------------------------------------------------
    def _build_check_items(self) -> List[CheckItem]:
        return [
            # ===== 一、身份鉴别 =====
            CheckItem(
                id="IA-a", name="身份标识唯一、口令复杂并定期更换", category="身份鉴别",
                description="对登录用户进行身份标识和鉴别；身份标识唯一；不存在空口令账户；"
                            "鉴别信息具复杂度要求并定期更换（PasswordComplexity=1、ClearTextPassword=0、"
                            "最小长度/历史/最长使用期符合基线、LimitBlankPasswordUse=1）。",
                risk_level="高", verify_type="需结合基线",
                remediation="运行 gpedit.msc：计算机配置→Windows 设置→安全设置→账户策略→密码策略，"
                            "启用“密码必须符合复杂性要求”、设最小长度≥8、强制密码历史≥5、最长使用期≤90 天；"
                            "在“本地策略→安全选项”启用“不允许存储可还原加密的密码”和“限制本地账户使用空口令”。",
            ),
            CheckItem(
                id="IA-b", name="登录失败处理、超时退出和结束会话", category="身份鉴别",
                description="账户锁定策略（阈值/时长/重置）；屏幕保护启用且恢复时要求重新鉴别；"
                            "RDP 会话空闲超时（MaxIdleTime/MaxDisconnectionTime/fResetBroken）。",
                risk_level="中", verify_type="可直接核验",
                remediation="gpedit.msc 配置账户锁定策略（阈值≤5 次、锁定≥30 分钟）；在屏幕保护设置勾选"
                            "“在恢复时显示登录屏幕”且等待≤15 分钟；通过组策略配置 RDP 会话空闲超时。",
            ),
            CheckItem(
                id="IA-c", name="远程管理时保护鉴别信息传输", category="身份鉴别",
                description="RDP 强制 TLS（SecurityLayer=2）、加密级别≥3、启用网络级身份验证（NLA）、"
                            "绑定证书（SSLCertificateSHA1Hash 非空）。",
                risk_level="高", verify_type="可直接核验",
                remediation="gpedit.msc→管理模板→Windows 组件→远程桌面服务→远程桌面会话主机→安全，"
                            "设置“远程桌面服务使用 TLS 1.2”“要求运行带 NLA 的远程桌面”“设置客户端加密级别=高”。",
            ),
            CheckItem(
                id="IA-d", name="两种或以上组合鉴别（至少一种含密码技术）", category="身份鉴别",
                description="智能卡强制登录（scforceoption=1）或 Windows Hello/Entra ID（dsregcmd 显示 "
                            "NgcSet=YES 等）、组合两类因素。",
                risk_level="高", verify_type="需补充证据",
                remediation="部署智能卡/Windows Hello for Business/多因素认证，并确保每个管理入口强制组合鉴别；"
                            "以身份提供方 MFA 策略、成功/失败认证日志与受控登录测试作为证据。",
            ),

            # ===== 二、访问控制 =====
            CheckItem(
                id="AC-a", name="分配账户和权限，限制匿名和默认账户", category="访问控制",
                description="Administrators 与 Remote Desktop Users 组仅含经审批账户；"
                            "RestrictAnonymous/RestrictAnonymousSAM=1、EveryoneIncludesAnonymous=0、"
                            "LimitBlankPasswordUse=1；关键目录 ACL 合理。",
                risk_level="高", verify_type="需结合基线",
                remediation="审查高权限组成员；gpedit.msc 安全选项中启用“不允许 SAM 账户和共享的匿名枚举”"
                            "“不允许匿名 SID/名称枚举”“不将 Everyone 权限应用于匿名用户”。",
            ),
            CheckItem(
                id="AC-b", name="重命名或禁用默认账户并修改默认口令", category="访问控制",
                description="RID -500 内置管理员名称已非默认 Administrator（并已限制使用）；"
                            "RID -501 来宾账户 Enabled=False。",
                risk_level="高", verify_type="可直接核验",
                remediation="通过 Computer Management 重命名/禁用内置 Administrator 账户；禁用 Guest 账户；"
                            "仍使用的内置管理员应由密码库/LAPS 管理凭据。",
            ),
            CheckItem(
                id="AC-c", name="删除或停用多余、过期账户，避免共享账户", category="访问控制",
                description="无非必要的启用账户；闲置超过基线的启用账户应有责任人/审批；"
                            "管理员组均映射到唯一自然人或受控服务身份；无共享账户。",
                risk_level="高", verify_type="需补充证据",
                remediation="清理离职/转岗/过期临时账户；对服务/应急账户建立责任人、用途、审批与补偿控制；"
                            "以人员/工单/认证日志核对避免共享账户。",
            ),
            CheckItem(
                id="AC-d", name="最小权限和管理权限分离", category="访问控制",
                description="高权限组仅含审批管理角色；SeDebug/SeTcb/SeBackup 等高危特权仅授予系统组件或"
                            "确有职责的管理角色；审计/安全/运维职责分离。",
                risk_level="高", verify_type="需结合基线",
                remediation="将日常办公账户移出 Administrators；按制度分离职责；受规模限制时以审批+双人复核+"
                            "审计补偿控制。",
            ),
            CheckItem(
                id="AC-e", name="由授权主体配置访问控制策略并防止越权", category="访问控制",
                description="关键客体 Owner 为 SYSTEM/Administrators/TrustedInstaller 等授权主体；"
                            "普通用户不具有 WRITE_DAC/WRITE_OWNER/修改/完全控制。",
                risk_level="中", verify_type="需补充证据",
                remediation="以普通测试账户做受控访问验证（预期 Access is denied），禁止在生产系统为验证而"
                            "修改系统文件；越权写入/改 ACL 应被拒绝。",
            ),
            CheckItem(
                id="AC-f", name="访问控制粒度达到用户/进程和文件/数据库表级", category="访问控制",
                description="ACL 精确到命名用户/授权组/服务身份；关键服务使用 LocalService/NetworkService/"
                            "虚拟服务账户/专用低权账号，避免无必要使用 LocalSystem。",
                risk_level="中", verify_type="需结合基线",
                remediation="核查关键文件/目录 ACL 与服务的独立运行身份；数据库表/字段级权限需在数据库内"
                            "单独核查。",
            ),
            CheckItem(
                id="AC-g", name="对重要主体和客体设置安全标记并实施强制访问控制", category="访问控制",
                description="采用 Windows 强制完整性控制（MIC，icacls/SDDL 可见 Mandatory Label）或 "
                            "Purview/AIP/WDAC 等标签/强制访问控制产品。",
                risk_level="中", verify_type="需补充证据",
                remediation="部署 WDAC/App Control（强制模式）或 Purview 信息保护；标准 NTFS ACL 不等同于"
                            "强制访问控制，低级别主体访问高级别客体应被拒绝并产生审计/告警。",
            ),

            # ===== 三、安全审计 =====
            CheckItem(
                id="AU-a", name="启用安全审计，覆盖每个用户和重要事件", category="安全审计",
                description="高级审计策略覆盖登录/注销、账户登录、账户管理、策略更改、特权使用、系统事件等；"
                            "SCENoApplyLegacyAuditPolicy=1；安全日志启用可读取。",
                risk_level="高", verify_type="可直接核验",
                remediation="auditpol /set 或在 gpedit.msc→高级审计策略配置中启用关键子类别的“成功和失败”；"
                            "启用“强制审核策略子类别设置（忽略本地/组策略的类别设置）”。",
            ),
            CheckItem(
                id="AU-b", name="审计记录包含时间、用户、类型、成败等字段", category="安全审计",
                description="每条事件含 TimeCreated、事件 ID/类型、RecordId、主体 SID/用户名、对象/来源、"
                            "成功/失败结果等字段。",
                risk_level="中", verify_type="需补充证据",
                remediation="抽查安全日志事件（登录 4624/4625、账户管理 4720/4722/4725/4726、策略更改 4719），"
                            "确认字段完整；第三方平台同源事件字段应对应、时间同步。",
            ),
            CheckItem(
                id="AU-c", name="保护、留存并定期备份审计记录", category="安全审计",
                description="安全/系统/应用日志 enabled=true、maxSize 满足基线、retention/autoBackup 合理；"
                            "日志目录 ACL 限制；存在集中转发/计划备份证据。",
                risk_level="中", verify_type="需结合基线",
                remediation="在事件查看器或 wevtutil 中将日志设为“不覆盖/保留”或满时自动备份；配置 WEF/计划任务"
                            "备份；普通用户不应有 Security.evtx 写/删权限。",
            ),
            CheckItem(
                id="AU-d", name="保护审计进程，防止未授权中断", category="安全审计",
                description="Windows Event Log 服务 State=Running、StartMode=Auto、StartName=LocalService；"
                            "第三方审计/EDR 代理运行且自动启动。",
                risk_level="高", verify_type="需补充证据",
                remediation="禁止普通用户停止/更改 Event Log 服务（通过 sc sdshow 校验 SDDL）；在隔离测试环境"
                            "以普通账户做受控验证（预期拒绝并触发告警）。",
            ),

            # ===== 四、入侵防范 =====
            CheckItem(
                id="IP-a", name="最小安装，仅保留必要组件和应用", category="入侵防范",
                description="已安装角色/功能/应用/服务均能对应资产用途或白名单；无业务无关的高风险组件。",
                risk_level="中", verify_type="需结合基线",
                remediation="卸载/禁用与业务无关的调试工具、远程控制软件、游戏、下载工具；"
                            "以最小化安装基线逐项比对并记录保留理由（Get-WindowsOptionalFeature / 卸载项注册表）。",
            ),
            CheckItem(
                id="IP-b", name="关闭不需要的服务、默认共享和高危端口，启用防火墙", category="入侵防范",
                description="三配置文件防火墙启用（默认拒绝入站）；无业务需要的高危/管理端口不监听或已限制；"
                            "无未批准普通共享；AutoShareWks=0（如基线要求关闭管理共享）。",
                risk_level="高", verify_type="可直接核验",
                remediation="启用 Windows Defender 防火墙（netsh advfirewall set allprofiles state on）；"
                            "关闭非必要服务；按需限制/关闭 135/137-139/445/3389/5985 等端口；配置 AutoShareWks=0。",
            ),
            CheckItem(
                id="IP-c", name="限制网络管理终端的接入方式和地址范围", category="入侵防范",
                description="RDP/WinRM/SSH 等管理端口入站允许规则的 RemoteAddress 为获批管理网段/VPN，"
                            "非 Any/0.0.0.0/0；管理规则不应用于 Public 配置文件任意来源；IPsec 限制策略。",
                risk_level="高", verify_type="需结合基线",
                remediation="通过高级安全 Windows Defender 防火墙将管理规则远端地址限制为管理网段/VPN；"
                            "如由上游防火墙/零信任实施，需以命中日志和双向受控测试证明有效限制。",
            ),
            CheckItem(
                id="IP-d", name="发现已知漏洞并在测试评估后及时修补", category="入侵防范",
                description="OS 版本在支持期、构建号达到组织补丁基线；无逾期 Critical/Important 安全更新；"
                            "wuauserv/bits 服务正常。",
                risk_level="高", verify_type="需结合基线",
                remediation="通过 Windows Update/WSUS 及时安装安全补丁；紧急漏洞在规定时限内完成测试、审批与部署；"
                            "以凭证/代理扫描报告与风险闭环记录作为最终证据（Get-HotFix 不覆盖所有更新类型）。",
            ),
            CheckItem(
                id="IP-e", name="检测重要节点入侵并对严重事件报警", category="入侵防范",
                description="Defender/EDR 本机状态（实时防护/行为监视/篡改保护/网络保护/ASR）；"
                            "防火墙启用；HIDS/EDR 代理运行。",
                risk_level="高", verify_type="需补充证据",
                remediation="启用并确认 Defender 实时防护/行为监视/网络保护（阻止模式）；部署 EDR；"
                            "在授权环境触发测试告警证明发现-上报-通知值守链路有效。",
            ),

            # ===== 五、恶意代码防范 =====
            CheckItem(
                id="MC-a", name="识别并阻断恶意代码/入侵行为，及时更新特征库", category="恶意代码防范",
                description="防病毒/反恶意软件启用且实时防护、行为监视、IOAV、NIS 均开启；特征库最新；"
                            "PUA/网络保护处于阻止模式；第三方产品由管理平台接管时以第三方状态为准。",
                risk_level="高", verify_type="可直接核验",
                remediation="保持防病毒软件实时防护/行为监视/IOAV/NIS 开启、特征库最新；启用 PUA 与网络保护"
                            "（阻止模式）；以 EICAR 等安全样本验证发现-阻断-隔离-告警-日志闭环。",
            ),

            # ===== 六、可信验证 =====
            CheckItem(
                id="TV-a", name="基于可信根的可信验证（启动/程序/配置/动态）", category="可信验证",
                description="TPM 就绪、UEFI 安全启动开启、BitLocker 保护启动卷；"
                            "VBS 与 Credential Guard 等安全服务运行（Win11 默认）；WDAC/代码完整性策略强制；"
                            "可信验证/安全日志向安全管理中心转发。",
                risk_level="高", verify_type="需补充证据",
                remediation="启用 TPM、UEFI 安全启动、BitLocker；开启 VBS/Credential Guard（Win11 默认）；"
                            "部署 WDAC（强制模式）；在中心侧提供设备在线、可信破坏告警与接收记录并做端到端测试。",
            ),
        ]

    # ----------------------------------------------------------
    # 公共辅助：secedit 安全策略缓存
    # ----------------------------------------------------------
    def _load_secedit(self) -> Dict[str, str]:
        """导出本机安全策略（secedit /export）并解析为键值字典，缓存复用"""
        if self._secedit_cache is not None:
            return self._secedit_cache
        self._secedit_cache = {}
        fd, path = tempfile.mkstemp(suffix=".inf", prefix="zt_sec_")
        os.close(fd)
        try:
            out, _, rc = _run_cmd(f'secedit /export /cfg "{path}" /quiet')
            if rc == 0 and os.path.exists(path):
                with open(path, "r", encoding="utf-8", errors="replace") as f:
                    content = f.read()
                for line in content.splitlines():
                    m = re.match(r'\s*([A-Za-z][\w]*)\s*=\s*(.+)', line)
                    if m:
                        self._secedit_cache[m.group(1)] = m.group(2).strip()
        except Exception:
            pass
        finally:
            try:
                os.unlink(path)
            except OSError:
                pass
        return self._secedit_cache

    def _secedit_value(self, key: str, default: Any = None) -> Any:
        """读取 secedit 导出的安全策略值（字符串），未找到返回 default"""
        cache = self._load_secedit()
        return cache.get(key, default)

    def _secedit_int(self, key: str, default: int = 0) -> int:
        val = self._secedit_value(key)
        if val is None:
            return default
        try:
            # 处理 0xFFFFFFFF 等十六进制
            s = str(val).strip()
            if s.lower().startswith("0x"):
                return int(s, 16)
            return int(s)
        except ValueError:
            return default

    @staticmethod
    def _is_truthy_ps(obj: Any) -> bool:
        """判断 PowerShell 返回的布尔/字符串是否为真"""
        if isinstance(obj, bool):
            return obj
        if isinstance(obj, str):
            return obj.strip().lower() in ("true", "1", "yes")
        return bool(obj)

    # ============================================================
    # 一、身份鉴别
    # ============================================================
    def _check_IA_a(self) -> CheckResult:
        """IA-a 身份标识唯一、口令复杂并定期更换"""
        item = self._item("IA-a")
        problems, infos = [], []

        # —— 口令策略（secedit）——
        complexity = self._secedit_int("PasswordComplexity")
        clear_text = self._secedit_int("ClearTextPassword")
        min_len = self._secedit_int("MinimumPasswordLength")
        history = self._secedit_int("PasswordHistorySize")
        max_age = self._secedit_int("MaximumPasswordAge")
        min_age = self._secedit_int("MinimumPasswordAge")

        if complexity == 1:
            infos.append("口令复杂度: 已启用 ✓")
        else:
            problems.append("口令复杂度: 未启用 ✗(期望=1)")

        if clear_text == 0:
            infos.append("可还原加密: 已禁用 ✓")
        else:
            problems.append("可还原加密: 未禁用 ✗(期望=0)")

        if isinstance(min_len, int) and min_len >= SCREEN_MIN_PW_LEN:
            infos.append(f"最小长度: {min_len} 位 ✓")
        else:
            problems.append(f"最小长度: {min_len} 位 ⚠(初筛参考≥{SCREEN_MIN_PW_LEN}，需结合已批准基线)")

        if isinstance(history, int) and history >= SCREEN_PW_HISTORY:
            infos.append(f"口令历史: {history} 次 ✓")
        else:
            problems.append(f"口令历史: {history} 次 ⚠(初筛参考≥{SCREEN_PW_HISTORY}，需结合已批准基线)")

        # 最大值 -1 (0xFFFFFFFF) 表示永不过期
        if max_age == -1 or max_age == 0:
            problems.append(f"最长使用期: 永不过期/0 ✗(期望>0且≤{SCREEN_MAX_PW_AGE_DAYS}天)")
        elif isinstance(max_age, int) and 0 < max_age <= SCREEN_MAX_PW_AGE_DAYS:
            infos.append(f"最长使用期: {max_age} 天 ✓")
        else:
            problems.append(f"最长使用期: {max_age} 天 ⚠(初筛参考≤{SCREEN_MAX_PW_AGE_DAYS}天，需结合已批准基线)")

        if isinstance(min_age, int) and min_age >= 1:
            infos.append(f"最短使用期: {min_age} 天 ✓")
        else:
            problems.append(f"最短使用期: {min_age} 天 ⚠(初筛参考≥1天)")

        # —— LimitBlankPasswordUse ——
        lbp, ok = _read_reg_value(
            winreg.HKEY_LOCAL_MACHINE,
            r"SYSTEM\CurrentControlSet\Control\Lsa", "LimitBlankPasswordUse")
        if ok and lbp == 1:
            infos.append("限制空口令控制台登录: 已启用 ✓")
        else:
            problems.append("限制空口令控制台登录: 未启用 ✗(期望=1)")

        # —— 本地账户：PasswordRequired / SID 唯一 ——
        users, err = _ps_json(
            "Get-LocalUser | Select-Object Name,Enabled,PasswordRequired,"
            "PasswordLastSet,LastLogon,SID")
        if users is not None:
            user_list = users if isinstance(users, list) else [users]
            no_pw_required = [u.get("Name") for u in user_list
                              if self._is_truthy_ps(u.get("Enabled")) and not self._is_truthy_ps(u.get("PasswordRequired"))]
            sids = [str(u.get("SID")) for u in user_list if u.get("SID")]
            dup = len(sids) != len(set(sids))
            if no_pw_required:
                problems.append(f"存在启用但未要求口令的账户: {', '.join(no_pw_required)} ✗")
            else:
                infos.append("启用账户均要求口令（PasswordRequired）✓")
            if dup:
                problems.append("检测到重复 SID ✗")
            else:
                infos.append("SID 无重复 ✓")
        else:
            infos.append(f"（无法查询本地账户: {err}）")

        status = CheckStatus.FAIL if (complexity != 1 or clear_text != 0 or (lbp != 1 and ok)) else \
            (CheckStatus.WARN if problems else CheckStatus.PASS)
        detail = ("；".join(infos) + "；" if infos else "") + ("问题: " + "；".join(problems) if problems else "")
        return CheckResult(item, status, actual_value="；".join(infos),
                           expected_value="复杂度=1/明文=0/最小长度≥基线/历史≥基线/最长≤基线/LimitBlank=1",
                           detail=detail or "口令策略符合要求")

    def _check_IA_b(self) -> CheckResult:
        """IA-b 登录失败处理、超时退出和结束会话"""
        item = self._item("IA-b")
        infos, problems = [], []

        # 账户锁定策略
        lock_thr = self._secedit_int("LockoutBadCount")
        lock_dur = self._secedit_int("LockoutDuration")
        reset_cnt = self._secedit_int("ResetLockoutCount")
        if isinstance(lock_thr, int) and 1 <= lock_thr <= SCREEN_LOCKOUT_THRESHOLD:
            infos.append(f"锁定阈值: {lock_thr} 次 ✓")
        else:
            problems.append(f"锁定阈值: {lock_thr} 次 ✗(期望 1~{SCREEN_LOCKOUT_THRESHOLD})")
        if isinstance(lock_dur, int) and lock_dur >= SCREEN_LOCKOUT_DURATION_MIN:
            infos.append(f"锁定时间: {lock_dur} 分钟 ✓")
        else:
            problems.append(f"锁定时间: {lock_dur} 分钟 ⚠(初筛参考≥{SCREEN_LOCKOUT_DURATION_MIN})")
        if isinstance(reset_cnt, int) and 0 < reset_cnt <= SCREEN_LOCKOUT_RESET_MIN:
            infos.append(f"计数器重置: {reset_cnt} 分钟 ✓")
        else:
            problems.append(f"计数器重置: {reset_cnt} 分钟 ⚠(初筛参考≤{SCREEN_LOCKOUT_RESET_MIN})")

        # 屏幕保护（HKCU）
        scr_active, ok1 = _read_reg_value(winreg.HKEY_CURRENT_USER, r"Control Panel\Desktop", "ScreenSaveActive")
        scr_secure, ok2 = _read_reg_value(winreg.HKEY_CURRENT_USER, r"Control Panel\Desktop", "ScreenSaverIsSecure")
        scr_to, ok3 = _read_reg_value(winreg.HKEY_CURRENT_USER, r"Control Panel\Desktop", "ScreenSaveTimeOut")
        if ok1 and str(scr_active) == "1":
            infos.append("屏幕保护: 已启用 ✓")
        else:
            problems.append("屏幕保护: 未启用 ✗")
        if ok2 and str(scr_secure) == "1":
            infos.append("恢复时登录: 已启用 ✓")
        else:
            problems.append("恢复时登录: 未启用 ✗")
        if ok3:
            to_sec = int(scr_to) if str(scr_to).isdigit() else 0
            if 0 < to_sec <= SCREEN_SCREENSAVER_TIMEOUT_SEC:
                infos.append(f"等待时间: {to_sec} 秒 ✓")
            else:
                problems.append(f"等待时间: {to_sec} 秒 ⚠(初筛参考≤{SCREEN_SCREENSAVER_TIMEOUT_SEC})")
        else:
            problems.append("等待时间: 未配置 ✗")

        # RDP 会话超时（HKLM，单位毫秒）
        for name, sub in (("MaxIdleTime", "MaxIdleTime"), ("MaxDisconnectionTime", "MaxDisconnectionTime")):
            val, ok = _read_reg_value(
                winreg.HKEY_LOCAL_MACHINE,
                r"SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services", sub)
            if ok and isinstance(val, int) and val > 0:
                infos.append(f"RDP {name}: {val} ms(非0) ✓")
            else:
                problems.append(f"RDP {name}: 未配置/为0 ⚠(应非0以限制空闲)")

        status = CheckStatus.PASS if not problems else (
            CheckStatus.WARN if all("⚠" in p for p in problems) else CheckStatus.FAIL)
        return CheckResult(item, status, actual_value="；".join(infos),
                           expected_value="锁定阈值≤5/锁屏恢复登录/空闲≤15分钟/RDP空闲超时非0",
                           detail="；".join(infos + problems))

    def _check_IA_c(self) -> CheckResult:
        """IA-c 远程管理时保护鉴别信息传输（RDP 加密）"""
        item = self._item("IA-c")
        data, err = _ps_json(
            "Get-CimInstance -Namespace 'root/cimv2/terminalservices' "
            "-ClassName Win32_TSGeneralSetting -Filter \"TerminalName='RDP-tcp'\" | "
            "Select-Object TerminalName,SecurityLayer,MinEncryptionLevel,UserAuthenticationRequired,"
            "SSLCertificateSHA1Hash")
        # GPO 注册表值
        sec_layer_gpo, _ = _read_reg_value(
            winreg.HKEY_LOCAL_MACHINE,
            r"SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services", "SecurityLayer")
        min_enc_gpo, _ = _read_reg_value(
            winreg.HKEY_LOCAL_MACHINE,
            r"SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services", "MinEncryptionLevel")

        infos, problems = [], []
        if data is None:
            problems.append(f"无法读取 RDP 监听器配置: {err}")
        else:
            d = data if isinstance(data, dict) else (data[0] if data else {})
            sl = d.get("SecurityLayer")
            me = d.get("MinEncryptionLevel")
            nla = d.get("UserAuthenticationRequired")
            cert = d.get("SSLCertificateSHA1Hash")
            # SecurityLayer: 2=强制TLS, 1=协商, 0=原生RDP(不安全)
            if sl == 2 or (sec_layer_gpo == 2):
                infos.append("SecurityLayer: 强制TLS(2) ✓")
            elif sl == 1:
                infos.append("SecurityLayer: 协商(1) ⚠需确认协商为TLS")
            else:
                problems.append(f"SecurityLayer: {sl} ✗(期望2/强制TLS；0=原生RDP不安全)")
            # MinEncryptionLevel: 3=High, 4=FIPS
            me_v = me if me is not None else min_enc_gpo
            if me_v in (3, 4):
                infos.append(f"MinEncryptionLevel: {me_v} ✓(High/FIPS)")
            else:
                problems.append(f"MinEncryptionLevel: {me_v} ✗(期望3或4)")
            if self._is_truthy_ps(nla):
                infos.append("网络级身份验证(NLA): 已启用 ✓")
            else:
                problems.append("网络级身份验证(NLA): 未启用 ✗(期望=1)")
            if cert and str(cert).strip() and str(cert).strip().lower() != "null":
                infos.append("已绑定证书(SSLCertificateSHA1Hash 非空) ✓")
            else:
                problems.append("未绑定证书(SSLCertificateSHA1Hash 为空) ⚠需核验证书有效期/信任链")

        status = CheckStatus.FAIL if problems and any("✗" in p for p in problems) else \
            (CheckStatus.WARN if problems else CheckStatus.PASS)
        return CheckResult(item, status, actual_value="；".join(infos),
                           expected_value="SecurityLayer=2/MinEncryptionLevel=3或4/NLA=1/证书非空",
                           detail="；".join(infos + problems))

    def _check_IA_d(self) -> CheckResult:
        """IA-d 两种或以上组合鉴别（需补充证据）"""
        item = self._item("IA-d")
        infos, problems = [], []

        scforce, ok = _read_reg_value(
            winreg.HKEY_LOCAL_MACHINE,
            r"SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System", "scforceoption")
        if ok and scforce == 1:
            infos.append("智能卡强制登录(scforceoption=1) ✓")
        else:
            infos.append("未配置智能卡强制登录（或采用其他组合鉴别方式）")

        out, _, _ = _run_cmd("dsregcmd /status")
        dsreg_hits = {}
        for line in out.splitlines():
            for kw in ("AzureAdJoined", "NgcSet", "DeviceId", "TenantId"):
                if kw in line and ":" in line:
                    dsreg_hits[kw] = line.split(":", 1)[-1].strip()
        if dsreg_hits:
            infos.append("dsregcmd 旁证: " + "；".join(f"{k}={v}" for k, v in dsreg_hits.items()))
            if dsreg_hits.get("NgcSet", "").upper() == "YES":
                infos.append("Windows Hello(NgcSet=YES) ✓")

        evidence = "本项需补充证据：身份提供方 MFA 策略、用户绑定、成功/失败认证日志与受控登录测试；" \
                   "仅配置两种因素但允许任一单独登录不属于组合鉴别。"
        has_strong = (ok and scforce == 1) or dsreg_hits.get("NgcSet", "").upper() == "YES"
        status = CheckStatus.INFO
        detail = "；".join(infos) + "。" + evidence
        return CheckResult(item, status, actual_value="；".join(infos),
                           expected_value="组合两类因素且至少一种含密码技术（如口令+动态令牌/证书PIN/生物特征+设备）",
                           detail=detail)

    # ============================================================
    # 二、访问控制
    # ============================================================
    def _check_AC_a(self) -> CheckResult:
        """AC-a 分配账户和权限，限制匿名和默认账户"""
        item = self._item("AC-a")
        infos, problems = [], []

        # 匿名/默认账户相关安全选项
        ra, _ = _read_reg_value(winreg.HKEY_LOCAL_MACHINE, r"SYSTEM\CurrentControlSet\Control\Lsa", "RestrictAnonymous")
        ras, _ = _read_reg_value(winreg.HKEY_LOCAL_MACHINE, r"SYSTEM\CurrentControlSet\Control\Lsa", "RestrictAnonymousSAM")
        eia, _ = _read_reg_value(winreg.HKEY_LOCAL_MACHINE, r"SYSTEM\CurrentControlSet\Control\Lsa", "EveryoneIncludesAnonymous")
        lbp, _ = _read_reg_value(winreg.HKEY_LOCAL_MACHINE, r"SYSTEM\CurrentControlSet\Control\Lsa", "LimitBlankPasswordUse")

        if ras == 1:
            infos.append("RestrictAnonymousSAM=1 ✓")
        else:
            problems.append(f"RestrictAnonymousSAM={ras} ✗(期望=1)")
        if ra in (1, 2):
            infos.append(f"RestrictAnonymous={ra} ✓")
        else:
            problems.append(f"RestrictAnonymous={ra} ⚠(期望=1或更严格)")
        if eia == 0:
            infos.append("EveryoneIncludesAnonymous=0 ✓")
        else:
            problems.append(f"EveryoneIncludesAnonymous={eia} ✗(期望=0)")
        if lbp == 1:
            infos.append("LimitBlankPasswordUse=1 ✓")
        else:
            problems.append(f"LimitBlankPasswordUse={lbp} ⚠(期望=1)")

        # 高权限组成员（用 SID 避免中英文组名差异）
        for sid, label in (("S-1-5-32-544", "Administrators"), ("S-1-5-32-555", "Remote Desktop Users")):
            members, err = _ps_json(
                f"Get-LocalGroupMember -Group (Get-LocalGroup -SID '{sid}').Name | "
                f"Select-Object Name,ObjectClass,PrincipalSource")
            if members is None:
                infos.append(f"{label} 组: 无法查询({err})")
                continue
            mlist = members if isinstance(members, list) else [members]
            names = [m.get("Name") for m in mlist]
            infos.append(f"{label} 组成员: {', '.join(names) if names else '(空)'}")
            if sid == "S-1-5-32-544" and len(mlist) > 1:
                problems.append(f"Administrators 含 {len(mlist)} 个成员，请核实是否均为必要账户 ⚠")

        status = CheckStatus.FAIL if any("✗" in p for p in problems) else (
            CheckStatus.WARN if problems else CheckStatus.PASS)
        detail = "；".join(infos + problems)
        return CheckResult(item, status, actual_value="；".join(infos),
                           expected_value="RestrictAnonymousSAM=1/EveryoneIncludesAnonymous=0/LimitBlank=1；高权限组仅含审批账户",
                           detail=detail + "。（关键目录 ACL 需结合系统默认继承与业务需求人工判定）")

    def _check_AC_b(self) -> CheckResult:
        """AC-b 重命名或禁用默认账户"""
        item = self._item("AC-b")
        users, err = _ps_json(
            "Get-LocalUser | Where-Object { $_.SID.Value -match '-(500|501)$' } | "
            "Select-Object Name,Enabled,SID")
        if users is None:
            return CheckResult(item, CheckStatus.ERROR, detail=f"无法查询内置账户: {err}")
        ulist = users if isinstance(users, list) else [users]
        infos, problems = [], []
        for u in ulist:
            sid = str(u.get("SID", ""))
            name = u.get("Name", "")
            enabled = self._is_truthy_ps(u.get("Enabled"))
            if sid.endswith("-500"):
                if name.lower() != "administrator":
                    infos.append(f"内置管理员(RID 500)已改名: {name} ✓")
                else:
                    problems.append("内置管理员(RID 500)仍为默认名 Administrator ⚠建议改名/严格限制")
                if enabled:
                    infos.append("内置管理员: 仍启用（如确需使用应由密码库/LAPS 管理）")
            elif sid.endswith("-501"):
                if not enabled:
                    infos.append("来宾账户(RID 501): 已禁用 ✓")
                else:
                    problems.append("来宾账户(RID 501): 仍处于启用状态 ✗(期望禁用)")
        status = CheckStatus.FAIL if any("✗" in p for p in problems) else (
            CheckStatus.WARN if problems else CheckStatus.PASS)
        return CheckResult(item, status, actual_value="；".join(infos),
                           expected_value="-500 改名或禁用/-501 禁用",
                           detail="；".join(infos + problems))

    def _check_AC_c(self) -> CheckResult:
        """AC-c 删除或停用多余、过期账户，避免共享账户（需补充证据）"""
        item = self._item("AC-c")
        users, err = _ps_json(
            "Get-LocalUser | Select-Object Name,Enabled,Description,PasswordLastSet,LastLogon,"
            "PrincipalSource")
        if users is None:
            return CheckResult(item, CheckStatus.ERROR, detail=f"无法查询本地账户: {err}")
        ulist = users if isinstance(users, list) else [users]
        stale = []
        cutoff = datetime.now().timestamp() - STALE_ACCOUNT_DAYS * 86400
        for u in ulist:
            if not self._is_truthy_ps(u.get("Enabled")):
                continue
            last = u.get("LastLogon")
            # PowerShell 返回 DateTime 序列化后为字符串
            try:
                from datetime import datetime as _dt
                if isinstance(last, str) and last:
                    lt = _dt.fromisoformat(last.replace("Z", "")).timestamp()
                    if lt < cutoff:
                        stale.append(u.get("Name"))
            except Exception:
                pass
        infos = [f"本地账户总数: {len(ulist)}"]
        problems = []
        if stale:
            problems.append(f"疑似闲置(>{STALE_ACCOUNT_DAYS}天未登录)的启用账户: {', '.join(stale)} ⚠需责任人/审批说明")
        else:
            infos.append(f"未发现明显闲置(>{STALE_ACCOUNT_DAYS}天)启用账户 ✓")
        evidence = "需补充证据：管理员组成员映射到唯一自然人/受控服务身份；以人员/工单/认证日志核对避免共享账户。"
        status = CheckStatus.WARN if problems else CheckStatus.INFO
        return CheckResult(item, status, actual_value="；".join(infos),
                           expected_value="无未解释的多余/过期/共享账户",
                           detail="；".join(infos + problems) + "。" + evidence)

    def _check_AC_d(self) -> CheckResult:
        """AC-d 最小权限和管理权限分离（需结合基线）"""
        item = self._item("AC-d")
        sids = ['S-1-5-32-544', 'S-1-5-32-548', 'S-1-5-32-549',
                'S-1-5-32-550', 'S-1-5-32-551', 'S-1-5-32-555']
        infos, problems = [], []
        for sid in sids:
            members, err = _ps_json(
                f"Get-LocalGroupMember -Group (Get-LocalGroup -SID '{sid}' -ErrorAction SilentlyContinue).Name "
                f"-ErrorAction SilentlyContinue | Select-Object Name,ObjectClass")
            if members is None:
                continue
            mlist = members if isinstance(members, list) else [members]
            if mlist:
                infos.append(f"[{sid}] 成员: {', '.join(str(m.get('Name')) for m in mlist)}")
        # 用户权限分配（whoami /priv 高危特权）
        out, _, _ = _run_cmd("whoami /priv")
        high_priv = [l for l in out.splitlines() if any(k in l for k in
                    ("SeDebugPrivilege", "SeTcbPrivilege", "SeBackupPrivilege",
                     "SeRestorePrivilege", "SeTakeOwnershipPrivilege", "SeLoadDriverPrivilege"))
                    and "Enabled" in l]
        if high_priv:
            problems.append(f"当前检查账户持有高危特权: {len(high_priv)} 项 ⚠需确认岗位需要且受控")
        else:
            infos.append("未检出当前账户高危特权 ✓")
        status = CheckStatus.WARN if problems else CheckStatus.INFO
        return CheckResult(item, status, actual_value="；".join(infos),
                           expected_value="高权限组仅含审批管理角色；高危特权授予系统组件/确有职责者",
                           detail="；".join(infos + problems) + "。（需结合已批准基线判定是否过度授权）")

    def _check_AC_e(self) -> CheckResult:
        """AC-e 由授权主体配置策略并防止越权（需补充证据）"""
        item = self._item("AC-e")
        target = os.path.join(os.environ.get("windir", "C:\\Windows"), "System32", "config")
        data, err = _ps_json(
            f"Get-Acl -LiteralPath '{target}' | Select-Object Owner,AreAccessRulesProtected")
        infos, problems = [], []
        if data is None:
            problems.append(f"无法读取 ACL: {err}")
        else:
            d = data if isinstance(data, dict) else (data[0] if data else {})
            owner = str(d.get("Owner", ""))
            infos.append(f"Owner: {owner}")
            if any(k in owner for k in ("SYSTEM", "Administrators", "TrustedInstaller")):
                infos.append("Owner 为授权主体 ✓")
            else:
                problems.append(f"Owner 非典型授权主体: {owner} ⚠")
        evidence = "需补充证据：以普通测试账户做受控访问验证（预期 Access is denied），禁止在生产修改系统文件。"
        status = CheckStatus.INFO
        return CheckResult(item, status, actual_value="；".join(infos),
                           expected_value="Owner 为 SYSTEM/Administrators/TrustedInstaller；普通用户无写/改 ACL 权限",
                           detail="；".join(infos + problems) + "。" + evidence)

    def _check_AC_f(self) -> CheckResult:
        """AC-f 访问控制粒度达到用户/进程/文件级（需结合基线）"""
        item = self._item("AC-f")
        windir = os.environ.get("windir", "C:\\Windows")
        targets = [os.path.join(windir, "System32"),
                   os.path.join(windir, "System32", "config")]
        infos, problems = [], []
        for t in targets:
            out, _, _ = _run_cmd(f'icacls "{t}"')
            infos.append(f"[{t}] ACL 行数: {len([l for l in out.splitlines() if ':' in l])}")
        svc, err = _ps_json(
            "Get-CimInstance Win32_Service | Select-Object Name,StartName,State")
        if svc is not None:
            slist = svc if isinstance(svc, list) else [svc]
            localsystem = [s.get("Name") for s in slist
                           if str(s.get("StartName", "")).lower() in ("localsystem", "local system", "system")]
            infos.append(f"使用 LocalSystem 运行的服务数: {len(localsystem)}")
            if localsystem:
                problems.append(f"存在使用 LocalSystem 的服务(应评估是否必要): {', '.join(localsystem[:8])} ⚠")
        status = CheckStatus.WARN if problems else CheckStatus.INFO
        return CheckResult(item, status, actual_value="；".join(infos),
                           expected_value="ACL 精确到命名主体；关键服务优先使用低权/虚拟账户",
                           detail="；".join(infos + problems) + "。（数据库表/字段级权限需在数据库内单独核查）")

    def _check_AC_g(self) -> CheckResult:
        """AC-g 安全标记与强制访问控制（需补充证据）"""
        item = self._item("AC-g")
        infos, problems = [], []
        # 检测 WDAC/SAC（Win11 可通过 DeviceGuard/SmartAppControl；Win10 多依赖 MIC）
        out, _, _ = _run_cmd('icacls "%windir%\\System32\\config"')
        if "Mandatory Label" in out:
            infos.append("检测到强制完整性控制(MIC)标签 ✓")
        else:
            infos.append("未在该客体上看到 MIC Mandatory Label（标准 NTFS ACL 属自主访问控制）")
        if self.is_win11:
            sac, ok = _read_reg_value(
                winreg.HKEY_LOCAL_MACHINE,
                r"SYSTEM\CurrentControlSet\Control\DeviceGuard\Scenarios\SmartAppControl", "State")
            if ok and sac == 2:
                infos.append("Smart App Control: 强制模式(enforce) ✓")
            elif ok and sac == 1:
                infos.append("Smart App Control: 评估模式(evaluate) ⚠")
            else:
                infos.append("Smart App Control: 未启用/不可用（或采用其他强制访问控制产品）")
        elif self.is_win_server:
            # Smart App Control 仅面向 Windows 客户端（Win10/11 消费者版），Windows Server 不支持；
            # Server 的强制访问控制以 WDAC / AppLocker 实现，须与客户端区分处理。
            infos.append("Windows Server 不支持 Smart App Control；强制访问控制以 WDAC / AppLocker 实现（推荐强制模式）⚠")
        detail_note = ("标准 NTFS ACL 不能自动等同强制访问控制；低级别主体访问高级别客体应被拒绝并产生审计/告警。"
                       "需补充证据：WDAC/App Control 或 Purview 标签产品的强制模式状态与管理平台记录。")
        status = CheckStatus.INFO
        return CheckResult(item, status, actual_value="；".join(infos),
                           expected_value="采用 MIC 或 WDAC/Purview 等标签/强制访问控制（强制模式）",
                           detail="；".join(infos) + "。" + detail_note)

    # ============================================================
    # 三、安全审计
    # ============================================================
    def _check_AU_a(self) -> CheckResult:
        """AU-a 启用安全审计，覆盖每个用户和重要事件"""
        item = self._item("AU-a")
        infos, problems = [], []

        out, _, _ = _run_cmd("auditpol /get /category:*")
        # 重要子类别（中文/英文关键字）→ 是否覆盖失败审计
        important = ["登录", "账户登录", "账户管理", "策略更改", "特权使用", "系统事件",
                     "Logon", "Account Logon", "Account Management", "Policy Change",
                     "Privilege Use", "System"]
        covered, missing = [], []
        lines = out.splitlines()
        for kw in important:
            found = False
            for line in lines:
                if kw in line:
                    # 行尾状态
                    tail = line.split("审核")[-1] if "审核" in line else line
                    low = tail.lower()
                    if "失败" in line or "failure" in low or "成功和失败" in line or "success and failure" in low:
                        found = True
                        break
                    if "成功" in line or "success" in low:
                        # 仅有成功，未覆盖失败
                        found = False
                        break
            if found:
                covered.append(kw)
            else:
                missing.append(kw)
        if covered:
            infos.append(f"已覆盖失败审计的重要子类别: {', '.join(covered)} ✓")
        if missing:
            problems.append(f"未覆盖失败审计的子类别: {', '.join(missing)} ⚠(仅成功或不启用不满足要求)")

        # SCENoApplyLegacyAuditPolicy
        val, ok = _read_reg_value(
            winreg.HKEY_LOCAL_MACHINE, r"SYSTEM\CurrentControlSet\Control\Lsa", "SCENoApplyLegacyAuditPolicy")
        if ok and val == 1:
            infos.append("SCENoApplyLegacyAuditPolicy=1 ✓(高级子类别覆盖旧类别)")
        else:
            problems.append(f"SCENoApplyLegacyAuditPolicy={val} ⚠(期望=1)")

        # 安全日志启用
        out2, _, _ = _run_cmd("wevtutil gl Security")
        enabled = "enabled: true" in out2.lower() or "enabled: true" in out2
        if enabled:
            infos.append("安全日志: 已启用 ✓")
        else:
            problems.append("安全日志: 未启用 ✗")

        status = CheckStatus.FAIL if any("✗" in p for p in problems) else (
            CheckStatus.WARN if problems else CheckStatus.PASS)
        return CheckResult(item, status, actual_value="；".join(infos),
                           expected_value="重要子类别启用成功+失败；SCENoApplyLegacyAuditPolicy=1；安全日志启用",
                           detail="；".join(infos + problems))

    def _check_AU_b(self) -> CheckResult:
        """AU-b 审计记录包含时间、用户、类型、成败等字段（需补充证据）"""
        item = self._item("AU-b")
        out, _, _ = _run_cmd("wevtutil qe Security /c:5 /rd:true /f:text")
        fields_present = all(k in out for k in ("Date:", "Time:", "Event ID:")) or \
                         all(k in out for k in ("日期:", "时间:", "事件 ID:"))
        infos = [f"抽取安全日志样本字符数: {len(out)}"]
        if fields_present:
            infos.append("样本含时间/事件ID等字段 ✓")
        else:
            infos.append("样本字段不明显（可能日志为空或语言差异）⚠")
        evidence = ("需补充证据：抽查 4624/4625、4720/4722/4725/4726、4719 等事件，确认 TimeCreated/主体 SID/"
                    "成败结果字段完整；第三方平台同源事件字段应对应。")
        status = CheckStatus.INFO
        return CheckResult(item, status, actual_value="；".join(infos),
                           expected_value="每条事件含时间/用户/类型/成败字段",
                           detail="；".join(infos) + "。" + evidence)

    def _check_AU_c(self) -> CheckResult:
        """AU-c 保护、留存并定期备份审计记录（需结合基线）"""
        item = self._item("AU-c")
        infos, problems = [], []
        for log in ("Security", "System", "Application"):
            out, _, _ = _run_cmd(f"wevtutil gl {log}")
            en = "enabled: true" in out.lower()
            retention = "retention: true" in out.lower()
            maxsize_line = [l for l in out.splitlines() if l.lower().startswith("maxsize")]
            if en:
                infos.append(f"{log}: 已启用 ✓")
            else:
                problems.append(f"{log}: 未启用 ✗")
            if retention:
                infos.append(f"{log}: retention=true(不覆盖) ✓")
            else:
                problems.append(f"{log}: 未设置 retention（达到上限可能覆盖旧事件）⚠需结合基线")
            if maxsize_line:
                infos.append(f"{log}: {maxsize_line[0].strip()}")
        # 计划任务中的备份/转发
        out2, _, _ = _run_cmd(
            'schtasks /query /fo LIST 2>nul | findstr /i "log audit event backup 日志 审计 备份"')
        if out2:
            infos.append("发现疑似日志备份/转发计划任务（需核实最近运行结果）")
        # WEF
        wef, _ = _read_reg_value(
            winreg.HKEY_LOCAL_MACHINE,
            r"SOFTWARE\Policies\Microsoft\Windows\EventLog\EventForwarding\SubscriptionManager", "")
        if wef:
            infos.append("配置了 WEF 事件转发订阅 ✓")
        status = CheckStatus.FAIL if any("✗" in p for p in problems) else (
            CheckStatus.WARN if problems else CheckStatus.PASS)
        return CheckResult(item, status, actual_value="；".join(infos),
                           expected_value="enabled=true；maxSize≥基线；retention/autoBackup 合理；集中转发/备份证据",
                           detail="；".join(infos + problems))

    def _check_AU_d(self) -> CheckResult:
        """AU-d 保护审计进程，防止未授权中断（需补充证据）"""
        item = self._item("AU-d")
        data, err = _ps_json(
            "Get-CimInstance Win32_Service -Filter \"Name='EventLog'\" | "
            "Select-Object Name,State,StartMode,StartName")
        infos, problems = [], []
        if data is None:
            problems.append(f"无法读取 Event Log 服务: {err}")
        else:
            d = data if isinstance(data, dict) else (data[0] if data else {})
            infos.append(f"EventLog: State={d.get('State')}, StartMode={d.get('StartMode')}, StartName={d.get('StartName')}")
            if str(d.get("State")).lower() == "running" and str(d.get("StartMode")).lower() == "auto":
                infos.append("Event Log 服务运行且自动启动 ✓")
            else:
                problems.append("Event Log 服务未处于 Running/Auto ✗")
        evidence = "需补充证据：在隔离测试环境以普通账户做受控验证（预期 Access is denied），管理平台应产生告警。"
        status = CheckStatus.INFO if not problems else CheckStatus.FAIL
        return CheckResult(item, status, actual_value="；".join(infos),
                           expected_value="EventLog State=Running/StartMode=Auto/StartName=LocalService；普通用户不可停止",
                           detail="；".join(infos + problems) + "。" + evidence)

    # ============================================================
    # 四、入侵防范
    # ============================================================
    def _check_IP_a(self) -> CheckResult:
        """IP-a 最小安装，仅保留必要组件和应用（需结合基线）"""
        item = self._item("IP-a")
        infos, problems = [], []

        # 客户端可选组件（Get-WindowsOptionalFeature 仅客户端可用；Get-WindowsFeature 仅服务器，个人OS跳过）
        feats, err = _ps_json(
            "Get-WindowsOptionalFeature -Online | Where-Object State -eq 'Enabled' | "
            "Select-Object FeatureName")
        if feats is not None:
            flist = feats if isinstance(feats, list) else [feats]
            names = [f.get("FeatureName") for f in flist]
            infos.append(f"已启用可选功能: {len(names)} 项（{', '.join(names[:12])}{'...' if len(names) > 12 else ''}）")
        else:
            infos.append(f"无法枚举可选功能: {err}")

        # 已安装应用（避免 Win32_Product 触发 MSI 修复）
        apps_out, _, _ = _run_cmd(
            'reg query "HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Uninstall" 2>nul & '
            'reg query "HKLM\\SOFTWARE\\WOW6432Node\\Microsoft\\Windows\\CurrentVersion\\Uninstall" 2>nul')
        app_names = re.findall(r"DisplayName\s+REG_SZ\s+(.+)", apps_out)
        infos.append(f"已安装应用(注册表): {len(app_names)} 项")

        # 已配置服务
        svc, err2 = _ps_json(
            "Get-CimInstance Win32_Service | Select-Object Name,DisplayName,State,StartMode")
        if svc is not None:
            slist = svc if isinstance(svc, list) else [svc]
            running = [s.get("Name") for s in slist if str(s.get("State")).lower() == "running"]
            infos.append(f"已配置服务: {len(slist)} 项，运行中: {len(running)} 项")

        detail_note = "本项无固定“应为空”输出，须将结果与最小化安装基线/软件白名单逐项比对并记录保留理由。"
        status = CheckStatus.INFO
        return CheckResult(item, status, actual_value="；".join(infos),
                           expected_value="已安装组件/应用/服务均能对应资产用途或白名单",
                           detail="；".join(infos) + "。" + detail_note)

    def _check_IP_b(self) -> CheckResult:
        """IP-b 关闭不需要的服务、默认共享和高危端口，启用防火墙"""
        item = self._item("IP-b")
        infos, problems = [], []

        # 防火墙三配置文件
        prof, err = _ps_json(
            "Get-NetFirewallProfile -PolicyStore ActiveStore | "
            "Select-Object Name,Enabled,DefaultInboundAction")
        if prof is not None:
            plist = prof if isinstance(prof, list) else [prof]
            for p in plist:
                en = self._is_truthy_ps(p.get("Enabled"))
                inbound = str(p.get("DefaultInboundAction", "")).lower()
                if en and inbound == "block":
                    infos.append(f"防火墙 {p.get('Name')}: 启用且默认拒绝入站 ✓")
                else:
                    problems.append(f"防火墙 {p.get('Name')}: 未启用或默认允许入站 ✗(期望启用+Block)")
        else:
            problems.append(f"无法读取防火墙配置: {err}")

        # 监听高危端口
        conns, err2 = _ps_json(
            "Get-NetTCPConnection -State Listen | Select-Object LocalAddress,LocalPort,OwningProcess")
        high = {"135": "RPC", "137": "NetBIOS", "138": "NetBIOS-DGM", "139": "NetBIOS-SSN",
                "445": "Microsoft-DS", "3389": "RDP", "5985": "WinRM", "5986": "WinRM-SSL", "1433": "MSSQL"}
        listening = []
        if conns is not None:
            clist = conns if isinstance(conns, list) else [conns]
            for c in clist:
                port = str(c.get("LocalPort"))
                if port in high:
                    listening.append(f"{port}({high[port]})")
        if listening:
            problems.append(f"高危/管理端口监听中: {', '.join(sorted(set(listening)))} ⚠无业务需要应限制/关闭")
        else:
            infos.append("未发现常见高危/管理端口监听 ✓")

        # 默认共享
        shares, err3 = _ps_json("Get-SmbShare | Select-Object Name,Special")
        admin_shares = []
        if shares is not None:
            slist = shares if isinstance(shares, list) else [shares]
            for s in slist:
                n = str(s.get("Name", "")).upper()
                if n in ("C$", "ADMIN$", "IPC$"):
                    admin_shares.append(n)
        autoshares, _ = _read_reg_value(
            winreg.HKEY_LOCAL_MACHINE,
            r"SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters", "AutoShareWks")
        if admin_shares:
            problems.append(f"存在管理共享: {', '.join(admin_shares)} ⚠(如基线要求关闭，应 AutoShareWks=0)")
        else:
            infos.append("未发现 C$/ADMIN$/IPC$ 类默认共享 ✓")
        if autoshares == 0:
            infos.append("AutoShareWks=0（已显式禁用自动管理共享）✓")
        else:
            infos.append(f"AutoShareWks={autoshares}（未显式禁用自动共享，IPC$可能为系统所需，需按业务判定）")

        status = CheckStatus.FAIL if any("✗" in p for p in problems) else (
            CheckStatus.WARN if problems else CheckStatus.PASS)
        return CheckResult(item, status, actual_value="；".join(infos),
                           expected_value="防火墙启用+默认拒绝；无业务需要的高危/管理端口不监听；无未批准共享",
                           detail="；".join(infos + problems))

    def _check_IP_c(self) -> CheckResult:
        """IP-c 限制网络管理终端的接入方式和地址范围（需结合基线）"""
        item = self._item("IP-c")
        mgmt_ports = ["22", "3389", "5985", "5986"]
        script = (
            "$rules = Get-NetFirewallRule -PolicyStore ActiveStore -Enabled True "
            "-Direction Inbound -Action Allow; "
            "$out = @(); foreach($r in $rules){ "
            "$pf = $r | Get-NetFirewallPortFilter; "
            "if($pf.LocalPort -in @('22','3389','5985','5986')){ "
            "$af = $r | Get-NetFirewallAddressFilter; "
            "$out += [pscustomobject]@{DisplayName=$r.DisplayName; Profile=[string]$r.Profile; "
            "Protocol=$pf.Protocol; LocalPort=[string]$pf.LocalPort; RemoteAddress=[string]$af.RemoteAddress} } }; "
            "$out"
        )
        rules, err = _ps_json(script)
        infos, problems = [], []
        if rules is None:
            infos.append(f"无法查询管理端口入站规则: {err}（可能由上游防火墙/零信任实施）")
        else:
            rlist = rules if isinstance(rules, list) else [rules]
            for r in rlist:
                ra = str(r.get("RemoteAddress", ""))
                name = r.get("DisplayName", "")
                port = r.get("LocalPort", "")
                profile = str(r.get("Profile", ""))
                if ra in ("Any", "0.0.0.0/0", "*", "") or "Any" in ra:
                    problems.append(f"管理端口 {port} 规则「{name}」远端地址为 {ra} ⚠(非获批网段，Public 配置下尤危险)")
                else:
                    infos.append(f"管理端口 {port} 规则「{name}」远端地址: {ra} ✓")
        status = CheckStatus.WARN if problems else (CheckStatus.INFO if not infos else CheckStatus.PASS)
        return CheckResult(item, status, actual_value="；".join(infos) if infos else "无管理端口入站允许规则",
                           expected_value="管理端口远端地址为获批网段/VPN，非 Any/0.0.0.0/0；不用于 Public 任意来源",
                           detail="；".join(infos + problems) + "。（如由上游防火墙/零信任实施，需以命中日志+双向受控测试证明）")

    def _check_IP_d(self) -> CheckResult:
        """IP-d 发现已知漏洞并在测试评估后及时修补（需结合基线；Win10/Win11/Server 补丁基线不同）"""
        item = self._item("IP-d")
        sys_out, _, _ = _run_cmd(
            'powershell -NoProfile -Command "Get-ComputerInfo | '
            'Select-Object WindowsProductName,OsBuildNumber,OsArchitecture"')
        infos, problems = [], []
        build = None
        prod_name = ""
        try:
            d = json.loads(sys_out)
            build = int(d.get("OsBuildNumber", 0))
            prod_name = str(d.get("WindowsProductName", "") or "")
            infos.append(f"产品: {prod_name or '未知'}，构建号: {build}，架构: {d.get('OsArchitecture')}")
        except Exception:
            infos.append("（无法读取系统版本信息）")

        # 按 OS 设置最低构建基线（Server 按具体版本区分，不可与桌面基线混用）
        if self.is_win_server:
            min_build = MIN_BUILD_WIN_SERVER
            for name, b in SERVER_MIN_BUILD.items():
                if name in prod_name:
                    min_build = b
                    break
            os_tag = prod_name or "Windows Server"
        else:
            min_build = MIN_BUILD_WIN11 if self.is_win11 else MIN_BUILD_WIN10
            os_tag = "Win11" if self.is_win11 else "Win10"
        if build is not None:
            if build >= min_build:
                infos.append(f"构建号达到{os_tag}最低补丁基线(≥{min_build}) ✓")
            else:
                problems.append(f"构建号 {build} 低于{os_tag}最低补丁基线 {min_build} ✗")

        # 最近补丁
        hf_out, _, _ = _run_cmd(
            'powershell -NoProfile -Command "Get-HotFix | Sort-Object InstalledOn -Descending | '
            'Select-Object -First 5 HotFixID,InstalledOn"')
        try:
            hfs = json.loads(hf_out)
            hlist = hfs if isinstance(hfs, list) else [hfs]
            infos.append(f"最近补丁: {', '.join(str(h.get('HotFixID')) for h in hlist if h.get('HotFixID'))}")
        except Exception:
            infos.append("（未能枚举已安装补丁）")

        # 待安装更新（COM，仅查本机 WSUS/Windows Update 数据源）
        pending, err = _ps_json(
            "$s = New-Object -ComObject Microsoft.Update.Session; "
            "$se = $s.CreateUpdateSearcher(); "
            "$p = $se.Search(\"IsInstalled=0 and Type='Software'\").Updates | "
            "Select-Object Title,MsrcSeverity")
        if pending is not None:
            plist = pending if isinstance(pending, list) else [pending]
            crit = [p for p in plist if str(p.get("MsrcSeverity", "")).lower() in ("critical", "important")]
            if crit:
                problems.append(f"存在 {len(crit)} 个待安装 Critical/Important 安全更新 ✗")
            else:
                infos.append("无待安装 Critical/Important 安全更新 ✓")
        else:
            infos.append(f"（无法查询待安装更新(需 Windows Update 数据源): {err}）")

        # wuauserv / bits
        svc, _ = _ps_json(
            "Get-Service wuauserv,bits | Select-Object Name,Status,StartType")
        if svc is not None:
            slist = svc if isinstance(svc, list) else [svc]
            for s in slist:
                infos.append(f"{s.get('Name')}: {s.get('Status')}/{s.get('StartType')}")

        status = CheckStatus.FAIL if any("✗" in p for p in problems) else (
            CheckStatus.WARN if problems else CheckStatus.PASS)
        return CheckResult(item, status, actual_value="；".join(infos),
                           expected_value=f"构建号≥{min_build}；无逾期 Critical/Important 更新；更新服务正常",
                           detail="；".join(infos + problems) + "。（Get-HotFix 不覆盖所有更新类型，最终须以扫描报告+风险闭环为准）")

    def _check_IP_e(self) -> CheckResult:
        """IP-e 检测重要节点入侵并对严重事件报警（需补充证据；Win10/Win11 SYN 防护实现不同）"""
        item = self._item("IP-e")
        infos, problems = [], []

        mp, err = _ps_json(
            "Get-MpComputerStatus | Select-Object AMServiceEnabled,AntivirusEnabled,RealTimeProtectionEnabled,"
            "BehaviorMonitorEnabled,IoavProtectionEnabled,NISEnabled,IsTamperProtected,"
            "DefenderSignaturesOutOfDate,AntivirusSignatureAge")
        if mp is not None:
            d = mp if isinstance(mp, dict) else (mp[0] if mp else {})
            flags = {
                "AMServiceEnabled": "反恶意软件服务", "AntivirusEnabled": "防病毒",
                "RealTimeProtectionEnabled": "实时防护", "BehaviorMonitorEnabled": "行为监视",
                "IoavProtectionEnabled": "IOAV", "NISEnabled": "NIS",
            }
            for k, label in flags.items():
                if self._is_truthy_ps(d.get(k)):
                    infos.append(f"{label}: 开启 ✓")
                else:
                    problems.append(f"{label}: 未开启 ✗")
            if not self._is_truthy_ps(d.get("IsTamperProtected")):
                problems.append("防篡改保护: 未启用 ⚠")
            if self._is_truthy_ps(d.get("DefenderSignaturesOutOfDate")):
                problems.append("Defender 特征库过期 ✗")
            age = d.get("AntivirusSignatureAge")
            if isinstance(age, int) and age > 1:
                problems.append(f"特征库年龄: {age} 天 ⚠(初筛参考≤1天)")
        else:
            infos.append(f"无法读取 Defender 状态: {err}")

        # 网络保护与 PUA（Get-MpPreference）
        pref, err2 = _ps_json(
            "Get-MpPreference | Select-Object EnableNetworkProtection,PUAProtection,"
            "AttackSurfaceReductionRules_Ids,AttackSurfaceReductionRules_Actions")
        if pref is not None:
            p = pref if isinstance(pref, dict) else (pref[0] if pref else {})
            np = p.get("EnableNetworkProtection")
            if np == 1:
                infos.append("网络保护: 阻止模式(1) ✓")
            elif np == 2:
                infos.append("网络保护: 审核模式(2) ⚠(不能证明已阻断)")
            else:
                problems.append(f"网络保护: {np} ✗(期望=1阻止)")
            pua = p.get("PUAProtection")
            if pua == 1:
                infos.append("PUA 保护: 阻止模式(1) ✓")
            elif pua == 0:
                problems.append("PUA 保护: 已禁用 ✗(期望=1)")

        # SYN 防护：新版 Windows（Win11、Windows Server 2016+）由 TCP/IP 栈动态实现，
        # 旧版 Win10 依赖 SynAttackProtect 注册表；Server 与 Win11 同属现代栈，须与 Win10 区分处理。
        if self.is_win11 or self.is_win_server:
            tag = "Windows Server" if self.is_win_server else "Win11"
            infos.append(f"{tag}：SYN 防护由 TCP/IP 栈动态实现（不再依赖 SynAttackProtect 注册表，缺失不判不合规）")
        else:
            syn, ok = _read_reg_value(
                winreg.HKEY_LOCAL_MACHINE,
                r"SYSTEM\CurrentControlSet\Services\Tcpip\Parameters", "SynAttackProtect")
            if ok and syn == 1:
                infos.append("SynAttackProtect=1 ✓(旧版 Win10 SYN 防护已启用)")
            else:
                problems.append("SynAttackProtect 未启用 ⚠(旧版 Win10 建议启用 SYN 防护；新版由栈动态实现)")

        # HIDS/EDR 代理服务
        agents, _ = _ps_json(
            "Get-CimInstance Win32_Service | Where-Object { $_.Name -match "
            "'sense|defender|sysmon|edr|ids|agent|falcon|sentinel|carbon' -or "
            "$_.DisplayName -match 'Defender|Endpoint|EDR|入侵|安全代理' } | "
            "Select-Object Name,DisplayName,State,StartMode")
        if agents is not None:
            alist = agents if isinstance(agents, list) else [agents]
            running = [a.get("Name") for a in alist if str(a.get("State")).lower() == "running"]
            if running:
                infos.append(f"检测到安全代理服务运行: {', '.join(running)}")

        evidence = "需补充证据：在授权环境触发测试告警，证明严重事件可被发现/上报/通知值守；仅服务运行不能证明报警链路有效。"
        status = CheckStatus.FAIL if any("✗" in p for p in problems) else (
            CheckStatus.WARN if problems else CheckStatus.PASS)
        return CheckResult(item, status, actual_value="；".join(infos),
                           expected_value="Defender 关键布尔=True/特征库最新；网络保护=1；EDR 运行且自动启动",
                           detail="；".join(infos + problems) + "。" + evidence)

    # ============================================================
    # 五、恶意代码防范
    # ============================================================
    def _check_MC_a(self) -> CheckResult:
        """MC-a 识别并阻断恶意代码/入侵行为，及时更新特征库"""
        item = self._item("MC-a")
        infos, problems = [], []

        mp, err = _ps_json(
            "Get-MpComputerStatus | Select-Object AMServiceEnabled,AntivirusEnabled,AntispywareEnabled,"
            "RealTimeProtectionEnabled,BehaviorMonitorEnabled,IoavProtectionEnabled,NISEnabled,"
            "IsTamperProtected,AntivirusSignatureVersion,AntivirusSignatureLastUpdated,"
            "AntivirusSignatureAge,DefenderSignaturesOutOfDate,FullScanAge,QuickScanAge")
        if mp is not None:
            d = mp if isinstance(mp, dict) else (mp[0] if mp else {})
            flags = {
                "AMServiceEnabled": "反恶意软件服务", "AntivirusEnabled": "防病毒",
                "AntispywareEnabled": "反间谍", "RealTimeProtectionEnabled": "实时防护",
                "BehaviorMonitorEnabled": "行为监视", "IoavProtectionEnabled": "IOAV", "NISEnabled": "NIS",
            }
            for k, label in flags.items():
                if self._is_truthy_ps(d.get(k)):
                    infos.append(f"{label}: 开启 ✓")
                else:
                    problems.append(f"{label}: 未开启 ✗")
            if not self._is_truthy_ps(d.get("IsTamperProtected")):
                problems.append("防篡改保护未启用 ⚠")
            if self._is_truthy_ps(d.get("DefenderSignaturesOutOfDate")):
                problems.append("特征库过期 ✗")
            age = d.get("AntivirusSignatureAge")
            if isinstance(age, int):
                if age <= 1:
                    infos.append(f"特征库年龄: {age} 天 ✓")
                else:
                    problems.append(f"特征库年龄: {age} 天 ⚠(初筛参考≤1天)")
        else:
            problems.append(f"无法读取 Defender 状态: {err}")

        # 防护策略
        pref, _ = _ps_json(
            "Get-MpPreference | Select-Object DisableRealtimeMonitoring,DisableBehaviorMonitoring,"
            "DisableIOAVProtection,DisableScriptScanning,PUAProtection,EnableNetworkProtection,"
            "SignatureUpdateInterval,MAPSReporting")
        if pref is not None:
            p = pref if isinstance(pref, dict) else (pref[0] if pref else {})
            for k, label in (("DisableRealtimeMonitoring", "实时监视"),
                             ("DisableBehaviorMonitoring", "行为监视"),
                             ("DisableIOAVProtection", "IOAV"),
                             ("DisableScriptScanning", "脚本扫描")):
                if self._is_truthy_ps(p.get(k)):
                    problems.append(f"{label}: 被禁用 ✗")
            np = p.get("EnableNetworkProtection")
            if np == 1:
                infos.append("网络保护: 阻止模式 ✓")
            elif np == 2:
                infos.append("网络保护: 审核模式 ⚠")
            pua = p.get("PUAProtection")
            if pua == 1:
                infos.append("PUA 保护: 阻止模式 ✓")

        # SecurityCenter2 登记的杀毒产品（兼容第三方接管）
        av, _ = _ps_json(
            "Get-CimInstance -Namespace root/SecurityCenter2 -ClassName AntiVirusProduct "
            "-ErrorAction SilentlyContinue | Select-Object displayName,productState")
        if av is not None:
            alist = av if isinstance(av, list) else [av]
            names = [a.get("displayName") for a in alist if a.get("displayName")]
            if names:
                infos.append(f"安全中心登记杀软: {', '.join(names)}")

        status = CheckStatus.FAIL if any("✗" in p for p in problems) else (
            CheckStatus.WARN if problems else CheckStatus.PASS)
        return CheckResult(item, status, actual_value="；".join(infos),
                           expected_value="实时防护/行为监视/IOAV/NIS=True；特征库最新；PUA/网络保护=1",
                           detail="；".join(infos + problems) +
                           "。（第三方产品以管理平台状态/病毒库版本/隔离记录为准，不误判 Defender 被接管）")

    # ============================================================
    # 六、可信验证
    # ============================================================
    def _check_TV_a(self) -> CheckResult:
        """TV-a 基于可信根的可信验证（需补充证据；Win10/Win11/Server 基线不同）"""
        item = self._item("TV-a")
        infos, problems = [], []

        # TPM
        tpm, err = _ps_json(
            "Get-Tpm | Select-Object TpmPresent,TpmReady,TpmEnabled,TpmActivated,TpmOwned,"
            "ManagedAuthLevel")
        if tpm is not None:
            d = tpm if isinstance(tpm, dict) else (tpm[0] if tpm else {})
            present = self._is_truthy_ps(d.get("TpmPresent"))
            # Win11 / Windows Server 2016+ 均要求 TPM 2.0（HVCI/Credential Guard/Shielded VM 前置）；
            # Win10 接受 TPM 1.2+。Server 与客户端在 TPM 强制要求上一致，不可按 Win10 处理。
            if present:
                infos.append("TPM 存在 ✓")
            else:
                problems.append("TPM 不存在 ✗")
            for k in ("TpmReady", "TpmEnabled", "TpmActivated"):
                if self._is_truthy_ps(d.get(k)):
                    infos.append(f"{k}: ✓")
                else:
                    problems.append(f"{k}: 未满足 ✗")
            # Win11 / Server 下 TPM 2.0 为强制要求，缺失判不合规；Win10 为推荐
            if not present and (self.is_win11 or self.is_win_server):
                tag = "Windows Server" if self.is_win_server else "Win11"
                problems.append(f"{tag} 要求 TPM 2.0，缺失属不合规 ✗")
        else:
            problems.append(f"无法读取 TPM: {err}")

        # UEFI 安全启动
        out, _, rc = _run_powershell("Confirm-SecureBootUEFI")
        if rc == 0 and "True" in out:
            infos.append("UEFI 安全启动: 已启用 ✓")
        else:
            problems.append("UEFI 安全启动: 未启用/不支持 ✗")

        # BitLocker
        bd, _, _ = _run_cmd("manage-bde -status C:")
        if "Protection On" in bd or "保护已开启" in bd:
            infos.append("BitLocker 系统卷: 保护开启 ✓")
        elif bd:
            problems.append("BitLocker 系统卷: 未开启保护 ⚠(数据/启动链保护旁证)")
        else:
            infos.append("（无法查询 BitLocker 状态）")

        # VBS / Device Guard / Credential Guard
        dg, err2 = _ps_json(
            "Get-CimInstance -Namespace 'root\\Microsoft\\Windows\\DeviceGuard' "
            "-ClassName Win32_DeviceGuard | Select-Object VirtualizationBasedSecurityStatus,"
            "SecurityServicesConfigured,SecurityServicesRunning,CodeIntegrityPolicyEnforcementStatus,"
            "UsermodeCodeIntegrityPolicyEnforcementStatus")
        if dg is not None:
            d = dg if isinstance(dg, dict) else (dg[0] if dg else {})
            vbs = d.get("VirtualizationBasedSecurityStatus")
            if vbs == 2:
                infos.append("VBS: 已启用并运行(2) ✓")
            elif vbs in (1, 3):
                infos.append(f"VBS: 状态={vbs} ⚠(期望=2 已启用运行)")
            else:
                problems.append(f"VBS: 状态={vbs} ✗(期望=2)")
            svc_run = d.get("SecurityServicesRunning")
            if self.is_win11:
                # Win11 默认启用 VBS/Credential Guard，期望运行
                if svc_run:
                    infos.append(f"运行的安全服务: {svc_run} ✓")
                else:
                    problems.append("Win11 未运行 Credential Guard/VBS 安全服务 ✗(Win11 默认应启用)")
            elif self.is_win_server:
                # Windows Server：VBS/Credential Guard 自 Server 2019 起受支持（Server 2016 支持有限，
                # 且需显式启用）；与 Win11 默认启用不同，按“建议启用”处理并提示版本差异。
                if svc_run:
                    infos.append(f"运行的安全服务: {svc_run} ✓")
                else:
                    infos.append("Windows Server 未运行 VBS/Credential Guard 安全服务"
                                 "（Server 2019/2022 建议启用，Server 2016 支持有限，非默认启用）⚠")
            else:
                # Win10 为推荐项
                if svc_run:
                    infos.append(f"运行的安全服务: {svc_run} ✓")
                else:
                    infos.append("Win10 未运行 VBS 安全服务（推荐启用，非强制基线）⚠")
            ci = d.get("CodeIntegrityPolicyEnforcementStatus")
            if ci == 2:
                infos.append("代码完整性(WDAC): 强制执行(2) ✓")
            elif ci == 1:
                infos.append("代码完整性(WDAC): 审核模式(1) ⚠(仅记录不阻断)")
        else:
            problems.append(f"无法读取 Device Guard: {err2}")

        # CodeIntegrity 日志
        ci_out, _, _ = _run_cmd(
            "wevtutil gl Microsoft-Windows-CodeIntegrity/Operational")
        if "enabled: true" in ci_out.lower():
            infos.append("CodeIntegrity/Operational 日志: 已启用 ✓")

        evidence = ("需补充证据：可信验证/安全日志向安全管理中心转发的本机配置与中心侧接收记录、可信破坏告警；"
                    "WDAC 场景应以强制模式运行，仅审核模式不阻断。"
                    "Windows Server 与 Win10/Win11 在可信验证实现上存在差异：Server 不支持 Smart App Control，"
                    "VBS/Credential Guard 默认未启用且 Server 2016 支持有限，须按服务器版基线单独评估。")
        status = CheckStatus.FAIL if any("✗" in p for p in problems) else (
            CheckStatus.WARN if problems else CheckStatus.PASS)
        return CheckResult(item, status, actual_value="；".join(infos),
                           expected_value="TPM就绪/SecureBoot开启/BitLocker保护/VBS运行/WDAC强制"
                                          "(Win11/Server 要求 TPM 2.0；Server 建议启用 VBS+CG)",
                           detail="；".join(infos + problems) + "。" + evidence)

    # ----------------------------------------------------------
    # 调度入口
    # ----------------------------------------------------------
    def _item(self, item_id: str) -> CheckItem:
        for it in self.check_items:
            if it.id == item_id:
                return it
        # 兜底（理论上不会触发）
        return CheckItem(id=item_id, name=item_id, category="未分类")

    def run_single(self, item_id: str) -> Optional[CheckResult]:
        method_map = {
            "IA-a": self._check_IA_a, "IA-b": self._check_IA_b, "IA-c": self._check_IA_c, "IA-d": self._check_IA_d,
            "AC-a": self._check_AC_a, "AC-b": self._check_AC_b, "AC-c": self._check_AC_c, "AC-d": self._check_AC_d,
            "AC-e": self._check_AC_e, "AC-f": self._check_AC_f, "AC-g": self._check_AC_g,
            "AU-a": self._check_AU_a, "AU-b": self._check_AU_b, "AU-c": self._check_AU_c, "AU-d": self._check_AU_d,
            "IP-a": self._check_IP_a, "IP-b": self._check_IP_b, "IP-c": self._check_IP_c,
            "IP-d": self._check_IP_d, "IP-e": self._check_IP_e,
            "MC-a": self._check_MC_a,
            "TV-a": self._check_TV_a,
        }
        method = method_map.get(item_id)
        if method is None:
            return None
        result = method()
        result.os_target = self.target_os
        return result

    def run_all(self, item_ids: List[str] = None, evidence_dir: str = "",
                progress_callback: Callable[[int, int, str], None] = None,
                cancel_event=None) -> List[CheckResult]:
        self.evidence_dir = evidence_dir
        self._results = []

        if item_ids is None:
            ids_to_run = [item.id for item in self.check_items
                          if (self.target_os == "win10" and item.win10_compatible) or
                             (self.target_os == "win11" and item.win11_compatible) or
                             (self.target_os == "win_server" and item.win_server_compatible)]
        else:
            ids_to_run = item_ids

        # 建立 id -> item 映射，避免依赖数字 ID
        item_by_id = {item.id: item for item in self.check_items}

        total = len(ids_to_run)
        for idx, cid in enumerate(ids_to_run):
            # 检查是否被取消（每项检查前检测）
            if cancel_event is not None and cancel_event.is_set():
                break

            name = item_by_id[cid].name if cid in item_by_id else cid
            if progress_callback:
                progress_callback(idx + 1, total, name)

            try:
                result = self.run_single(cid)
                if result is None:
                    item = item_by_id.get(cid) or CheckItem(
                        id=cid, name=cid, category="未分类")
                    result = CheckResult(item, CheckStatus.ERROR,
                                         detail=f"未找到检查项实现: {cid}")
                if evidence_dir:
                    result = self._collect_evidence(result)
                result.os_target = self.target_os
            except Exception as exc:
                item = item_by_id.get(cid) or CheckItem(
                    id=cid, name=cid, category="未分类")
                result = CheckResult(
                    item, CheckStatus.ERROR,
                    detail=f"检查执行异常: {exc}\n{traceback.format_exc()}",
                    os_target=self.target_os,
                )
            self._results.append(result)

        return self._results

    def _collect_evidence(self, result: CheckResult) -> CheckResult:
        """对高风险检查项导出相关注册表作为证据"""
        if result.item.risk_level != "高":
            return result

        export_map = {
            "IA-a": [(winreg.HKEY_LOCAL_MACHINE, r"SYSTEM\CurrentControlSet\Control\Lsa", "lsa_password_policy")],
            "IA-b": [
                (winreg.HKEY_LOCAL_MACHINE, r"SYSTEM\CurrentControlSet\Control\Lsa", "lsa_lockout"),
                (winreg.HKEY_CURRENT_USER, r"Control Panel\Desktop", "screensaver"),
            ],
            "IA-c": [(winreg.HKEY_LOCAL_MACHINE,
                      r"SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services", "rdp_security")],
            "AC-a": [(winreg.HKEY_LOCAL_MACHINE, r"SYSTEM\CurrentControlSet\Control\Lsa", "lsa_anonymous")],
            "AC-b": [(winreg.HKEY_LOCAL_MACHINE,
                      r"SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System", "default_accounts")],
            "AU-a": [(winreg.HKEY_LOCAL_MACHINE, r"SYSTEM\CurrentControlSet\Control\Lsa", "audit_legacy")],
            "IP-b": [(winreg.HKEY_LOCAL_MACHINE,
                      r"SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters", "autoshares")],
            "IP-d": [(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate", "wu_policy")],
            "TV-a": [(winreg.HKEY_LOCAL_MACHINE,
                      r"SYSTEM\CurrentControlSet\Control\DeviceGuard", "deviceguard")],
        }

        exports = export_map.get(result.item.id, [])
        evidence_files = []
        for hive, subkey, label in exports:
            safe_filename = f"{result.item.id}_{label}.reg"
            filepath = os.path.join(self.evidence_dir, safe_filename)
            if _export_reg_key(hive, subkey, filepath):
                evidence_files.append(filepath)

        result.evidence = evidence_files
        return result

    def get_summary(self) -> dict:
        if not self._results:
            return {}
        summary = {"total": len(self._results),
                   "target_os": self.target_os,
                   "os_version": self.system_info.os_version,
                   "os_build": self.system_info.os_build}
        for s in CheckStatus:
            count = sum(1 for r in self._results if r.status == s)
            summary[s.value] = count
        high_risk_fails = sum(1 for r in self._results
                              if r.status in (CheckStatus.FAIL, CheckStatus.WARN)
                              and r.item.risk_level == "高")
        summary["high_risk_failures"] = high_risk_fails
        return summary

    def get_system_info_dict(self) -> dict:
        return {
            "hostname": self.system_info.hostname,
            "os_version": self.system_info.os_version,
            "os_build": self.system_info.os_build,
            "architecture": self.system_info.architecture,
            "username": self.system_info.username,
            "ip_addresses": ", ".join(self.system_info.ip_addresses),
            "target_os": self.target_os,
            "check_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        }
