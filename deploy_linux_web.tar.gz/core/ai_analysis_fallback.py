# -*- coding: utf-8 -*-
"""
本地 AI 分析 fallback 生成器（零第三方依赖）

当未配置 DeepSeek API Key 或处于 Linux Web 精简部署环境时，
基于检查结果自动生成一份结构化的 "AI 智能分析与整改建议" Markdown 内容。

内容风格模仿资深等保测评师报告，包含执行摘要、分项详细分析、
整改优先级排序、合规映射四大板块；与桌面端 DeepSeek 分析板块在结构上保持一致。
"""

from typing import Dict, List


# GB/T 22239-2019 控制点映射
_GB_CATEGORY_MAP = {
    "身份鉴别": "8.1.1 身份鉴别",
    "访问控制": "8.1.2 访问控制",
    "安全审计": "8.1.3 安全审计",
    "入侵防范": "8.1.4 入侵防范",
    "恶意代码防范": "8.1.5 恶意代码防范",
    "可信验证": "8.1.6 可信验证 / 相关条款",
}

_STATUS_ICON = {
    "通过": "✓",
    "不通过": "✗",
    "警告": "⚠",
    "信息": "ℹ",
    "错误": "❌",
}

_RISK_ORDER = {"高": 0, "中": 1, "低": 2, "-": 3, "": 4}


def _host_display(system_info: Dict, platform_name: str = "Windows") -> str:
    hostname = system_info.get("hostname") or system_info.get("computer_name") or "未知主机"
    os_ver = (
        system_info.get("os_display")
        or system_info.get("os_version")
        or system_info.get("caption")
        or platform_name
    )
    return f"{hostname}（{os_ver}）"


def _overall_verdict(summary: Dict) -> str:
    failed = int(summary.get("不通过", 0) or 0)
    warn = int(summary.get("警告", 0) or 0)
    err = int(summary.get("错误", 0) or 0)
    high = int(summary.get("high_risk_failures", 0) or 0)
    if failed == 0 and warn == 0 and err == 0:
        return "符合"
    if high > 0 or failed >= 3:
        return "不符合（存在重大风险隐患）"
    if failed > 0 or err > 0:
        return "部分符合（存在中低风险问题）"
    return "基本符合（存在优化项）"


def generate_ai_analysis(
    system_info: Dict,
    check_results: List[Dict],
    summary: Dict,
    platform_name: str = "Windows",
) -> str:
    """
    生成本地 fallback 的 AI 智能分析与整改建议 Markdown 文本。

    Args:
        system_info: 主机系统信息字典
        check_results: 检查结果列表（to_dict 格式）
        summary: 检查摘要统计
        platform_name: 平台名称（Windows / Linux）

    Returns:
        Markdown 字符串，可直接传入 ReportGenerator._render_ai_section
    """
    host = _host_display(system_info, platform_name)
    total = int(summary.get("total", len(check_results)) or len(check_results))
    passed = int(summary.get("通过", 0) or 0)
    failed = int(summary.get("不通过", 0) or 0)
    warn = int(summary.get("警告", 0) or 0)
    info = int(summary.get("信息", 0) or 0)
    err = int(summary.get("错误", 0) or 0)
    high = int(summary.get("high_risk_failures", 0) or 0)
    verdict = _overall_verdict(summary)

    lines = []
    lines.append(
        f"好的，作为一名资深的网络安全等级保护测评师，我将根据您提供的{platform_name}"
        f"操作系统安全基线自动化检查结果，为您出具一份专业、详尽的分析报告。"
    )
    lines.append("")
    lines.append(f"## {platform_name} 操作系统安全基线检查分析报告")
    lines.append("")
    lines.append(
        f"**目标主机**：{host}  **检查时间**：{system_info.get('check_time', '未知')}  "
        f"**报告日期**：{system_info.get('report_date', '未知')}"
    )
    lines.append("")

    # 1. 执行摘要
    lines.append("## 1. 执行摘要（Executive Summary）")
    lines.append("")
    lines.append(
        f"本次对目标主机 **{system_info.get('hostname', '未知主机')}** 进行的 "
        f"{platform_name} 操作系统安全基线自动化检查，整体结论为 **{verdict}**。"
    )
    lines.append("")
    lines.append("核心统计：")
    lines.append(f"- 总检查项数：{total} 项")
    lines.append(f"- 通过项数：{passed} 项")
    lines.append(f"- 不通过项数：{failed} 项")
    lines.append(f"- 警告项数：{warn} 项")
    lines.append(f"- 信息项数：{info} 项")
    lines.append(f"- 检测异常：{err} 项")
    lines.append(f"- 重大风险隐患：{high} 项")
    lines.append("")
    if high > 0:
        lines.append(
            f"> ⚠️ **高风险提示**：本次检查共发现 {high} 个重大风险隐患，"
            "建议立即进行整改并复测，确保系统满足等保合规要求。"
        )
    elif failed > 0:
        lines.append(
            f"> 本次检查共发现 {failed} 个不通过项，建议按照下文优先级逐项整改。"
        )
    else:
        lines.append(
            "> 本次检查未发现明显不合规项，建议持续关注警告与信息项的优化空间。"
        )
    lines.append("")

    # 2. 分项详细分析
    lines.append("## 2. 分项详细分析（按控制域展开）")
    lines.append("")

    # 按类别分组
    by_cat: Dict[str, List[Dict]] = {}
    for r in check_results:
        cat = r.get("category") or "未分类"
        by_cat.setdefault(cat, []).append(r)

    # 固定顺序 + 实际出现的类别
    category_order = ["身份鉴别", "访问控制", "安全审计", "入侵防范", "恶意代码防范", "可信验证"]
    ordered_cats = [c for c in category_order if c in by_cat]
    ordered_cats += [c for c in by_cat if c not in category_order]

    has_problem = False
    for cat in ordered_cats:
        items = by_cat[cat]
        problems = [r for r in items if r.get("status") in ("不通过", "警告", "错误")]
        if not problems:
            continue
        has_problem = True
        lines.append(f"### {cat}")
        lines.append("")
        for r in problems:
            icon = _STATUS_ICON.get(r.get("status", ""), "?")
            name = r.get("name", "未知检查项")
            risk = r.get("risk", "-")
            detail = r.get("detail") or r.get("actual_value") or "无详细描述"
            remediation = r.get("remediation") or "请参考相关安全基线配置手册进行修复。"
            lines.append(f"**{icon} {name}**  （风险等级：{risk}）")
            lines.append("")
            lines.append(f"- **问题说明**：{detail}")
            lines.append(f"- **风险等级**：{risk}")
            lines.append(
                f"- **影响范围**：该问题可能导致系统面临{platform_name}基线合规风险，"
                "建议尽快修复以降低攻击面。"
            )
            lines.append(f"- **整改建议**：{remediation}")
            lines.append("")

    if not has_problem:
        lines.append("本次检查未发现需要整改的不通过或警告项，所有控制域均达到基线要求。")
        lines.append("")

    # 3. 整改优先级排序
    lines.append("## 3. 整改优先级排序")
    lines.append("")
    problems_all = [
        r for r in check_results
        if r.get("status") in ("不通过", "警告", "错误")
    ]
    if problems_all:
        problems_all.sort(
            key=lambda r: _RISK_ORDER.get(r.get("risk", "-"), 99)
        )
        lines.append("建议按以下优先级逐项整改：")
        lines.append("")
        for idx, r in enumerate(problems_all, 1):
            icon = _STATUS_ICON.get(r.get("status", ""), "?")
            risk = r.get("risk", "-")
            remediation = r.get("remediation") or "参考相关安全配置手册修复。"
            lines.append(
                f"{idx}. **{icon} {r.get('name', '未知项')}** "
                f"（{r.get('category', '未分类')} / 风险：{risk}）—— {remediation}"
            )
        lines.append("")
    else:
        lines.append("未发现需要整改的问题，可进入常态化监控阶段。")
        lines.append("")

    # 4. 合规映射
    lines.append("## 4. 合规映射")
    lines.append("")
    lines.append(
        "本次检查结果对照国家《信息安全技术 网络安全等级保护基本要求》"
        "(GB/T 22239-2019) 的控制点进行映射如下："
    )
    lines.append("")
    for cat in ordered_cats:
        clause = _GB_CATEGORY_MAP.get(cat, "相关条款")
        problems = [r for r in by_cat.get(cat, []) if r.get("status") in ("不通过", "警告", "错误")]
        status = "存在不合规项" if problems else "符合要求"
        lines.append(f"- **{cat}**：对应 {clause}，当前状态 **{status}**。")
    lines.append("")

    lines.append("---")
    lines.append("")
    lines.append(
        "*本分析由 Zero Two 本地智能分析引擎自动生成，未调用外部 AI 服务。"
        "如需更深入的定制化分析，可在桌面端配置 DeepSeek API Key 后重新生成报告。*"
    )

    return "\n".join(lines)
