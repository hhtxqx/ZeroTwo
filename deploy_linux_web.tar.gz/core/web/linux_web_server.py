# -*- coding: utf-8 -*-
"""
Zero Two — Linux 安全基线检查 Web 服务

仅使用 Python 标准库（http.server），无第三方依赖、无前端框架。
同网段其他主机可通过浏览器访问本服务，远程执行 Linux 安全基线检查并查看 EVA 风格报告。

启动方式（推荐使用 start_linux_web.sh）：
    python3 core/web/linux_web_server.py [--host 0.0.0.0] [--port 8080]

接口：
    GET  /                      返回 EVA 风格单页前端
    GET  /api/checks            返回检查项列表 JSON
    POST /api/run               启动检查（body: {"ids":[...]} 可选）；立即返回 {"ok":true}
    GET  /api/state             轮询检查进度与结果（不含完整 HTML）
    GET  /api/report            返回最近一次生成的 HTML 报告（text/html）
    GET  /api/download?fmt=html 下载最近一次生成的报告文件

Author: Zero Two Team
"""

import argparse
import json
import os
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs

# 将项目根目录加入 sys.path，便于直接复用 core/ 下的模块
_THIS_DIR = os.path.dirname(os.path.abspath(__file__))
_PROJECT_ROOT = os.path.dirname(os.path.dirname(_THIS_DIR))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

from utils.paths import project_root  # noqa: E402
from core.linux_checker import LinuxBaselineChecker  # noqa: E402
from core.report_generator import ReportGenerator  # noqa: E402
from core.ai_analysis_fallback import generate_ai_analysis  # noqa: E402

APP_HTML_PATH = os.path.join(_THIS_DIR, "app.html")
LINUX_REPORT_DIR = os.path.join(project_root(), "reports", "Linux")

# 全局运行状态（单进程内共享；Web 为单用户场景，足够）
_STATE = {
    "running": False,
    "done": False,
    "progress": 0,
    "total": 0,
    "current": "",
    "summary": None,
    "system_info": None,
    "results": [],
    "report_html": "",
    "report_path": "",
    "error": None,
}
_STATE_LOCK = threading.Lock()


def _set(**kwargs):
    with _STATE_LOCK:
        _STATE.update(kwargs)


def _get():
    with _STATE_LOCK:
        return dict(_STATE)


def _run_checks(item_ids):
    """后台线程：执行检查并生成报告。"""
    try:
        checker = LinuxBaselineChecker(target_os="linux")
        _set(running=True, done=False, progress=0, total=0, current="准备中...",
             summary=None, system_info=None, results=[], report_html="",
             report_path="", error=None)

        def _progress(idx, total, name):
            _set(progress=idx, total=total, current=name)

        results = checker.run_all(item_ids=item_ids, progress_callback=_progress)
        summary = checker.get_summary()
        sinfo = checker.get_system_info_dict()
        results_dict = [r.to_dict() for r in results]

        gen = ReportGenerator(report_dir=LINUX_REPORT_DIR, platform_name="Linux")
        ai_content = generate_ai_analysis(
            system_info=sinfo,
            check_results=results_dict,
            summary=summary,
            platform_name="Linux",
        )
        html_report = gen.generate(
            system_info=sinfo,
            check_results=results_dict,
            summary=summary,
            ai_content=ai_content,
        )
        path = gen.save(
            html_report,
            payload=gen.build_payload(sinfo, results_dict, summary, ai_content),
        )

        _set(running=False, done=True, progress=len(results), total=len(results),
             current="完成", summary=summary, system_info=sinfo,
             results=results_dict, report_html=html_report, report_path=path)
    except Exception as e:  # 防御性：单点异常不应让线程静默消失
        import traceback
        _set(running=False, done=True, error=f"{e}\n{traceback.format_exc()}")


# ============================================================
# HTTP 处理
# ============================================================
class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def _send_json(self, obj, code=200):
        data = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(data)

    def _send_text(self, text, content_type="text/plain; charset=utf-8", code=200):
        data = text.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(data)

    def _send_file(self, path, filename, content_type="application/octet-stream"):
        if not os.path.isfile(path):
            self._send_text("报告文件不存在", code=404)
            return
        with open(path, "rb") as f:
            data = f.read()
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Content-Disposition",
                         f'attachment; filename="{filename}"')
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path
        qs = parse_qs(parsed.query)

        if path in ("/", "/index.html"):
            if not os.path.isfile(APP_HTML_PATH):
                self._send_text("前端文件缺失: app.html", code=500)
                return
            with open(APP_HTML_PATH, "rb") as f:
                data = f.read()
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)
            return

        if path == "/api/checks":
            checker = LinuxBaselineChecker()
            items = [{
                "id": i.id,
                "name": i.name,
                "category": i.category,
                "description": i.description,
                "risk_level": i.risk_level,
                "remediation": i.remediation,
                "verify_type": i.verify_type,
            } for i in checker.get_check_items()]
            self._send_json({"ok": True, "items": items,
                             "platform": checker.system_info.os_version or "Linux",
                             "hostname": checker.system_info.hostname})
            return

        if path == "/api/state":
            st = _get()
            # 不下发完整 HTML，避免体积过大
            st.pop("report_html", None)
            self._send_json({"ok": True, **st})
            return

        if path == "/api/report":
            st = _get()
            html_report = st.get("report_html", "")
            if not html_report:
                self._send_text("尚未生成报告，请先执行检查。", code=404)
                return
            self._send_text(html_report, content_type="text/html; charset=utf-8")
            return

        if path == "/api/download":
            st = _get()
            fmt = (qs.get("fmt") or ["html"])[0]
            path_file = st.get("report_path", "")
            if not path_file or not os.path.isfile(path_file):
                self._send_text("尚未生成报告文件，请先执行检查。", code=404)
                return
            fname = os.path.basename(path_file)
            self._send_file(path_file, fname,
                            content_type="text/html; charset=utf-8")
            return

        self._send_text("Not Found", code=404)

    def do_POST(self):
        parsed = urlparse(self.path)
        if parsed.path != "/api/run":
            self._send_text("Not Found", code=404)
            return

        length = int(self.headers.get("Content-Length", 0) or 0)
        body = self.rfile.read(length) if length else b""
        item_ids = None
        if body:
            try:
                payload = json.loads(body.decode("utf-8"))
                item_ids = payload.get("ids")
            except (json.JSONDecodeError, ValueError):
                item_ids = None

        st = _get()
        if st.get("running"):
            self._send_json({"ok": False, "msg": "已有检查任务正在运行"}, code=409)
            return

        t = threading.Thread(target=_run_checks, args=(item_ids,), daemon=True)
        t.start()
        # 立即返回，前端轮询 /api/state
        self._send_json({"ok": True, "msg": "检查已启动"})
        return

    def log_message(self, fmt, *args):
        # 简化日志，避免刷屏
        sys.stderr.write("[web] " + (fmt % args) + "\n")


def get_lan_ips():
    """获取同网段可访问的 IP 列表（best-effort）。"""
    ips = []
    try:
        import socket
        hostname = socket.gethostname()
        for info in socket.getaddrinfo(hostname, None):
            ip = info[4][0]
            if ":" not in ip and not ip.startswith("127."):
                ips.append(ip)
    except Exception:
        pass
    return ips


def main():
    parser = argparse.ArgumentParser(description="Zero Two Linux 基线检查 Web 服务")
    parser.add_argument("--host", default="0.0.0.0",
                        help="监听地址（默认 0.0.0.0，允许同网段访问）")
    parser.add_argument("--port", type=int, default=8080,
                        help="监听端口（默认 8080）")
    args = parser.parse_args()

    os.makedirs(LINUX_REPORT_DIR, exist_ok=True)

    httpd = ThreadingHTTPServer((args.host, args.port), Handler)
    local = f"http://127.0.0.1:{args.port}"
    print("=" * 56)
    print("  Zero Two — Linux 安全基线检查 Web 服务已启动")
    print("=" * 56)
    print(f"  本机访问 : {local}")
    for ip in get_lan_ips():
        print(f"  同网段访问: http://{ip}:{args.port}")
    print("  (按 Ctrl+C 停止服务)")
    print("=" * 56)
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\n正在停止服务...")
        httpd.shutdown()


if __name__ == "__main__":
    main()
