# -*- coding: utf-8 -*-
"""
Linux 安全基线检查引擎（Web 版）

检查项方向对齐 Windows 版《等保 2.0 个人操作系统测评项》，共 6 个控制域、22 个子项：
    - 身份鉴别     IA-a ~ IA-d  (4 项)
    - 访问控制     AC-a ~ AC-g  (7 项)
    - 安全审计     AU-a ~ AU-d  (4 项)
    - 入侵防范     IP-a ~ IP-e  (5 项)
    - 恶意代码防范 MC-a        (1 项)
    - 可信验证     TV-a         (1 项)

设计目标（与用户约定一致）：
    - 最大化复用 core/checker 的数据模型（CheckItem / CheckResult / CheckStatus / SystemInfo）
      + core/report_generator 的 EVA 风格 HTML 报告（零 Windows 依赖，可跨平台）。
    - 检查逻辑通过 subprocess 调用 shell 命令实现（天然满足"用 shell 检查"）。
    - 难实现的项做简化或降级（INFO / 需补充证据），但保留检查与出报告的原始能力。

Author: Zero Two Team
"""

import getpass
import os
import platform
import re
import socket
import subprocess
import traceback
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Callable, Dict, List, Optional

# 复用 Windows 引擎的数据模型（winreg 已做跨平台保护，Linux 亦可导入）
from core.checker import CheckItem, CheckResult, CheckStatus, SystemInfo


# ============================================================
# Shell 工具函数
# ============================================================
def _run(cmd: str, timeout: int = 30, shell: bool = True):
    """执行 shell 命令，返回 (stdout, stderr, returncode)。"""
    try:
        proc = subprocess.run(
            cmd, shell=shell, capture_output=True, text=True,
            errors="replace", timeout=timeout,
        )
        return proc.stdout.strip(), proc.stderr.strip(), proc.returncode
    except subprocess.TimeoutExpired:
        return "", "命令超时", -1
    except FileNotFoundError:
        return "", "命令不存在", -1
    except Exception as e:  # pragma: no cover - 防御性
        return "", str(e), -1


def _read_file(path: str) -> Optional[str]:
    """安全读取文本文件，失败返回 None。"""
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            return f.read()
    except OSError:
        return None


def _parse_kv(text: str, sep: str = "=") -> Dict[str, str]:
    """把 key=value 文本解析为字典（忽略注释与空白）。"""
    out = {}
    if not text:
        return out
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, _, v = line.partition(sep)
        out[k.strip()] = v.strip().strip('"').strip("'")
    return out


def _parse_ssh_config(text: str) -> Dict[str, str]:
    """解析 sshd_config，遇到重复 key 以最后一个（或首个有效）为准，合并多值为最后值。"""
    out = {}
    for line in (text or "").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        # 支持 "Key value" 形式
        m = re.match(r"^(\w+)\s+(.+)$", line)
        if m:
            out[m.group(1)] = m.group(2).strip()
    return out


def _svc_active(name: str) -> Optional[bool]:
    """返回服务是否 active；未安装/查不到返回 None。"""
    out, _, rc = _run(f"systemctl is-active {name}", timeout=15)
    if rc != 0:
        # 尝试 service 命令兜底
        out2, _, rc2 = _run(f"service {name} status", timeout=15)
        if rc2 == 0 and ("running" in out2.lower() or "active" in out2.lower()):
            return True
        return False
    return out.strip() == "active"


def _svc_enabled(name: str) -> Optional[bool]:
    out, _, rc = _run(f"systemctl is-enabled {name}", timeout=15)
    if rc != 0:
        return False
    return out.strip() in ("enabled", "static", "generated")


# ============================================================
# Linux 检查器
# ============================================================
class LinuxBaselineChecker:
    """
    Linux 安全基线检查引擎（Web 版）

    接口与 Windows 版 BaselineChecker 尽量保持一致：
        - run_all(item_ids, evidence_dir, progress_callback, cancel_event)
        - run_single(item_id)
        - get_summary()
        - get_system_info_dict()
    返回 CheckResult（.to_dict() 结构），供 ReportGenerator 直接复用。
    """

    def __init__(self, target_os: str = "linux"):
        self.target_os = target_os
        self.system_info = self._gather_system_info()
        self.check_items = self._build_check_items()
        self._results: List[CheckResult] = []
        self.evidence_dir = ""
        # id -> 检查方法
        self._checks = {
            "IA-a": self._chk_ia_a,
            "IA-b": self._chk_ia_b,
            "IA-c": self._chk_ia_c,
            "IA-d": self._chk_ia_d,
            "AC-a": self._chk_ac_a,
            "AC-b": self._chk_ac_b,
            "AC-c": self._chk_ac_c,
            "AC-d": self._chk_ac_d,
            "AC-e": self._chk_ac_e,
            "AC-f": self._chk_ac_f,
            "AC-g": self._chk_ac_g,
            "AU-a": self._chk_au_a,
            "AU-b": self._chk_au_b,
            "AU-c": self._chk_au_c,
            "AU-d": self._chk_au_d,
            "IP-a": self._chk_ip_a,
            "IP-b": self._chk_ip_b,
            "IP-c": self._chk_ip_c,
            "IP-d": self._chk_ip_d,
            "IP-e": self._chk_ip_e,
            "MC-a": self._chk_mc_a,
            "TV-a": self._chk_tv_a,
        }

    # ---------- 系统信息 ----------
    def _gather_system_info(self) -> SystemInfo:
        si = SystemInfo(target_os=self.target_os)
        try:
            si.hostname = socket.gethostname()
        except Exception:
            si.hostname = "unknown"
        # 发行版信息
        rel = _read_file("/etc/os-release")
        if rel:
            kv = _parse_kv(rel)
            si.os_version = kv.get("PRETTY_NAME", "") or kv.get("NAME", "")
        if not si.os_version:
            out, _, _ = _run("uname -o", timeout=10)
            si.os_version = out or platform.system()
        si.os_build = platform.release()
        si.architecture = platform.machine()
        try:
            si.username = getpass.getuser()
        except Exception:
            si.username = os.environ.get("USER", "unknown")
        # IP 地址
        ips = []
        try:
            hostname = socket.gethostname()
            for info in socket.getaddrinfo(hostname, None):
                ip = info[4][0]
                if ip not in ips and not ip.startswith("127."):
                    ips.append(ip)
        except Exception:
            pass
        if not ips:
            out, _, _ = _run("hostname -I", timeout=10)
            ips = [x for x in out.split() if x]
        si.ip_addresses = ips
        return si

    # ---------- 检查项定义（22 项） ----------
    def _build_check_items(self) -> List[CheckItem]:
        return [
            CheckItem("IA-a", "身份鉴别-口令复杂度与老化策略", "身份鉴别",
                      "检查口令最小长度、最长使用期、历史、复杂度（pam_pwquality/cracklib）",
                      "高", "配置 /etc/login.defs 与 PAM 口令策略，满足等保口令复杂度与老化要求。",
                      "可直接核验"),
            CheckItem("IA-b", "身份鉴别-账户锁定策略", "身份鉴别",
                      "检查登录失败锁定（pam_faillock / pam_tally2）",
                      "高", "配置 pam_faillock deny<=5、unlock_time>=300，防止暴力破解。",
                      "可直接核验"),
            CheckItem("IA-c", "身份鉴别-远程登录认证安全", "身份鉴别",
                      "检查 SSH 配置（PermitRootLogin、PasswordAuthentication、PubkeyAuthentication）",
                      "高", "禁用 root 远程登录与密码登录，强制使用密钥认证。",
                      "可直接核验"),
            CheckItem("IA-d", "身份鉴别-双因子/智能卡认证", "身份鉴别",
                      "检查是否部署 2FA（pam_google_authenticator / pam_u2f / sssd）",
                      "中", "对高安全场景部署双因子认证。",
                      "需补充证据"),
            CheckItem("AC-a", "访问控制-空口令/匿名账户", "访问控制",
                      "检查 /etc/shadow 是否存在空口令账户",
                      "高", "锁定或删除空口令账户，确保无匿名登录。",
                      "可直接核验"),
            CheckItem("AC-b", "访问控制-多余管理员账户", "访问控制",
                      "检查 UID=0 账户是否仅 root",
                      "高", "移除除 root 外的 UID=0 账户，避免权限提升。",
                      "可直接核验"),
            CheckItem("AC-c", "访问控制-共享/重复口令账户", "访问控制",
                      "检查非系统账户是否存在相同口令哈希（共享口令）",
                      "中", "为不同账户设置独立口令，杜绝共享口令。",
                      "可直接核验"),
            CheckItem("AC-d", "访问控制-sudo 免密策略", "访问控制",
                      "检查 sudoers 中 NOPASSWD 配置是否过宽",
                      "中", "收紧 NOPASSWD 授权，仅对必要命令授权且需密码。",
                      "可直接核验"),
            CheckItem("AC-e", "访问控制-远程电源管理限制", "访问控制",
                      "检查是否将关机/重启等特权宽泛授予普通用户",
                      "中", "限制 shutdown/reboot 仅限授权管理员。",
                      "可直接核验"),
            CheckItem("AC-f", "访问控制-sudo 授权最小化", "访问控制",
                      "检查 sudo 是否授予 ALL（全体用户）而非专用管理员组",
                      "中", "sudo 授权限定到 wheel/admin 等专用组，避免授予 ALL。",
                      "可直接核验"),
            CheckItem("AC-g", "访问控制-SMB 匿名共享", "访问控制",
                      "检查 Samba 是否开启 guest/匿名共享",
                      "中", "关闭 Samba guest ok 与 map to guest，禁止匿名访问。",
                      "可直接核验"),
            CheckItem("AU-a", "安全审计-审计服务开启", "安全审计",
                      "检查 auditd 服务是否运行",
                      "高", "启用并运行 auditd 审计服务。",
                      "可直接核验"),
            CheckItem("AU-b", "安全审计-审计规则覆盖", "安全审计",
                      "检查审计规则是否覆盖关键文件（passwd/shadow/ssh 等）",
                      "中", "通过 auditctl 添加对关键配置文件的审计规则。",
                      "需补充证据"),
            CheckItem("AU-c", "安全审计-审计日志保护与留存", "安全审计",
                      "检查 /var/log/audit 权限与审计日志留存配置",
                      "中", "限制审计日志权限为 root，配置 max_log_file 与轮转。",
                      "可直接核验"),
            CheckItem("AU-d", "安全审计-审计开机自启", "安全审计",
                      "检查 auditd 是否开机自启",
                      "中", "启用 auditd 开机自启，保证重启后持续审计。",
                      "可直接核验"),
            CheckItem("IP-a", "入侵防范-高危服务最小化", "入侵防范",
                      "检查是否启用 telnet/rsh/rlogin/tftp/vsftpd 等高危服务",
                      "高", "关闭并卸载不必要的高危网络服务。",
                      "可直接核验"),
            CheckItem("IP-b", "入侵防范-默认网络共享", "入侵防范",
                      "检查 NFS/Samba 是否暴露可写共享",
                      "中", "关闭不必要的网络文件共享，或严格限制访问来源。",
                      "可直接核验"),
            CheckItem("IP-c", "入侵防范-不安全监听端口", "入侵防范",
                      "检查是否监听 telnet(23)/rservices(512-514) 等不安全端口",
                      "高", "关闭不安全端口服务，仅保留必要业务端口。",
                      "可直接核验"),
            CheckItem("IP-d", "入侵防范-补丁与漏洞管理", "入侵防范",
                      "检查系统是否存在待安装的安全更新",
                      "中", "及时安装安全更新，建立补丁管理流程。",
                      "可直接核验"),
            CheckItem("IP-e", "入侵防范-SYN 防护与防火墙", "入侵防范",
                      "检查 tcp_syncookies 与主机防火墙（ufw/nftables/iptables）状态",
                      "中", "开启 syncookies 与主機防火墙，仅放行必要端口。",
                      "可直接核验"),
            CheckItem("MC-a", "恶意代码防范-防病毒部署", "恶意代码防范",
                      "检查是否部署 ClamAV / rkhunter / chkrootkit 等防护",
                      "中", "部署并定期更新恶意代码防护工具。",
                      "可直接核验"),
            CheckItem("TV-a", "可信验证-安全启动与可信根", "可信验证",
                      "检查 Secure Boot 与 TPM 支持情况",
                      "中", "启用 Secure Boot 与 TPM，构建可信启动链。",
                      "需补充证据"),
        ]

    def get_check_items(self) -> List[CheckItem]:
        return self.check_items

    # ---------- 单项检查 ----------
    def run_single(self, item_id: str) -> Optional[CheckResult]:
        item = next((i for i in self.check_items if i.id == item_id), None)
        if item is None:
            return None
        fn = self._checks.get(item_id)
        if fn is None:
            return CheckResult(item, CheckStatus.INFO,
                               detail="该检查项暂未实现（Linux 适配中）。")
        try:
            return fn(item)
        except Exception as exc:
            return CheckResult(item, CheckStatus.ERROR,
                               detail=f"检查执行异常: {exc}\n{traceback.format_exc()}",
                               os_target=self.target_os)

    # ---------- 批量检查 ----------
    def run_all(self, item_ids: List[str] = None,
                evidence_dir: str = "",
                progress_callback: Callable[[int, int, str], None] = None,
                cancel_event=None) -> List[CheckResult]:
        self.evidence_dir = evidence_dir
        self._results = []
        ids_to_run = item_ids if item_ids else [i.id for i in self.check_items]
        item_by_id = {i.id: i for i in self.check_items}
        total = len(ids_to_run)
        for idx, cid in enumerate(ids_to_run):
            if cancel_event is not None and cancel_event.is_set():
                break
            name = item_by_id[cid].name if cid in item_by_id else cid
            if progress_callback:
                progress_callback(idx + 1, total, name)
            try:
                result = self.run_single(cid)
                if result is None:
                    item = item_by_id.get(cid) or CheckItem(id=cid, name=cid, category="未分类")
                    result = CheckResult(item, CheckStatus.ERROR, detail=f"未找到检查项实现: {cid}")
                result.os_target = self.target_os
            except Exception as exc:
                item = item_by_id.get(cid) or CheckItem(id=cid, name=cid, category="未分类")
                result = CheckResult(item, CheckStatus.ERROR,
                                     detail=f"检查执行异常: {exc}\n{traceback.format_exc()}",
                                     os_target=self.target_os)
            self._results.append(result)
        return self._results

    # ---------- 汇总 ----------
    def get_summary(self) -> dict:
        if not self._results:
            return {}
        summary = {
            "total": len(self._results),
            "target_os": self.target_os,
            "os_version": self.system_info.os_version,
            "os_build": self.system_info.os_build,
        }
        for s in CheckStatus:
            summary[s.value] = sum(1 for r in self._results if r.status == s)
        high_risk_fails = sum(
            1 for r in self._results
            if r.status in (CheckStatus.FAIL, CheckStatus.WARN) and r.item.risk_level == "高"
        )
        summary["high_risk_failures"] = high_risk_fails
        return summary

    def get_system_info_dict(self) -> dict:
        return {
            "hostname": self.system_info.hostname,
            "os_version": self.system_info.os_version,
            "os_build": self.system_info.os_build,
            "architecture": self.system_info.architecture,
            "username": self.system_info.username,
            "ip_addresses": ", ".join(self.system_info.ip_addresses),
            "target_os": self.target_os,
            "check_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        }

    # ============================================================
    # 各检查项实现
    # ============================================================
    # ---- 身份鉴别 ----
    def _chk_ia_a(self, item: CheckItem) -> CheckResult:
        login_defs = _read_file("/etc/login.defs")
        kv = _parse_kv(login_defs) if login_defs else {}
        min_len = kv.get("PASS_MIN_LEN", "0")
        max_days = kv.get("PASS_MAX_DAYS", "99999")
        min_days = kv.get("PASS_MIN_DAYS", "0")
        warn_age = kv.get("PASS_WARN_AGE", "0")
        # PAM 复杂度
        pam = ""
        for p in ("/etc/pam.d/common-password", "/etc/pam.d/password-auth",
                  "/etc/pam.d/system-auth"):
            t = _read_file(p)
            if t:
                pam += t + "\n"
        has_pwq = "pwquality" in pam or "cracklib" in pam
        m = re.search(r"minlen\s*=\s*(\d+)", pam)
        minlen_pam = m.group(1) if m else None

        checks = []
        ok = True
        if int(min_len) < 8:
            ok = False
            checks.append(f"PASS_MIN_LEN={min_len}(<8)")
        if int(max_days) > 90:
            ok = False
            checks.append(f"PASS_MAX_DAYS={max_days}(>90)")
        if not has_pwq:
            ok = False
            checks.append("未配置 pam_pwquality/cracklib 复杂度")
        actual = f"PASS_MIN_LEN={min_len}, PASS_MAX_DAYS={max_days}, 复杂度={'是' if has_pwq else '否'}"
        expected = "PASS_MIN_LEN>=8, PASS_MAX_DAYS<=90, 启用口令复杂度模块"
        if ok:
            return CheckResult(item, CheckStatus.PASS, actual, expected,
                               "口令策略符合等保要求。", os_target=self.target_os)
        return CheckResult(item, CheckStatus.FAIL, actual, expected,
                           "口令策略不达标：" + "；".join(checks) +
                           "。请在 /etc/login.defs 与 PAM 中加固。",
                           os_target=self.target_os)

    def _chk_ia_b(self, item: CheckItem) -> CheckResult:
        pam = ""
        for p in ("/etc/pam.d/common-auth", "/etc/pam.d/system-auth",
                  "/etc/pam.d/password-auth"):
            t = _read_file(p)
            if t:
                pam += t + "\n"
        has_faillock = "faillock" in pam
        has_tally = "pam_tally2" in pam
        m = re.search(r"deny\s*=\s*(\d+)", pam)
        deny = m.group(1) if m else None
        actual = f"faillock={'启用' if has_faillock else '否'}, tally2={'启用' if has_tally else '否'}" + \
                 (f", deny={deny}" if deny else "")
        expected = "启用登录失败锁定（deny<=5, unlock_time>=300）"
        if has_faillock or has_tally:
            if deny and int(deny) <= 5:
                return CheckResult(item, CheckStatus.PASS, actual, expected,
                                   "已配置账户锁定策略。", os_target=self.target_os)
            return CheckResult(item, CheckStatus.WARN, actual, expected,
                               "已配置锁定但阈值偏宽，建议 deny<=5。", os_target=self.target_os)
        return CheckResult(item, CheckStatus.FAIL, actual, expected,
                           "未配置登录失败锁定，存在暴力破解风险。建议部署 pam_faillock。",
                           os_target=self.target_os)

    def _chk_ia_c(self, item: CheckItem) -> CheckResult:
        sshd = _read_file("/etc/ssh/sshd_config")
        cfg = _parse_ssh_config(sshd) if sshd else {}
        permit_root = cfg.get("PermitRootLogin", "unset")
        pwd_auth = cfg.get("PasswordAuthentication", "unset")
        pubkey = cfg.get("PubkeyAuthentication", "unset")
        actual = f"PermitRootLogin={permit_root}, PasswordAuthentication={pwd_auth}, PubkeyAuthentication={pubkey}"
        expected = "PermitRootLogin=no/prohibit-password, 优先 PubkeyAuthentication=yes, 关闭密码登录更优"
        issues = []
        if permit_root not in ("no", "prohibit-password", "unset"):
            issues.append("允许 root 远程登录")
        if pwd_auth == "yes":
            issues.append("允许密码登录")
        if not issues:
            return CheckResult(item, CheckStatus.PASS, actual, expected,
                               "SSH 远程登录认证配置较安全。", os_target=self.target_os)
        return CheckResult(item, CheckStatus.WARN, actual, expected,
                           "SSH 配置建议加固：" + "；".join(issues) +
                           "。建议 PermitRootLogin=no 并启用密钥认证。",
                           os_target=self.target_os)

    def _chk_ia_d(self, item: CheckItem) -> CheckResult:
        pam = ""
        for p in ("/etc/pam.d/common-auth", "/etc/pam.d/system-auth",
                  "/etc/pam.d/password-auth", "/etc/pam.d/sshd"):
            t = _read_file(p)
            if t:
                pam += t + "\n"
        has_2fa = any(x in pam for x in
                      ("google_authenticator", "pam_u2f", "pam_python", "otp"))
        actual = "已部署2FA" if has_2fa else "未检测到2FA配置"
        if has_2fa:
            return CheckResult(item, CheckStatus.PASS, actual,
                               "部署双因子/智能卡认证",
                               "已部署双因子认证。", os_target=self.target_os)
        return CheckResult(item, CheckStatus.INFO, actual,
                           "部署双因子/智能卡认证",
                           "未在本机检测到双因子认证配置。如已通过集中认证平台（如 FreeIPA/AD+2FA）实现，需补充证据材料。",
                           os_target=self.target_os)

    # ---- 访问控制 ----
    def _chk_ac_a(self, item: CheckItem) -> CheckResult:
        shadow = _read_file("/etc/shadow")
        empty = []
        if shadow:
            for line in shadow.splitlines():
                parts = line.split(":")
                if len(parts) >= 2 and parts[1] == "" and parts[0] not in ("",):
                    empty.append(parts[0])
        actual = f"空口令账户: {', '.join(empty) if empty else '无'}"
        expected = "不存在空口令账户"
        if empty:
            return CheckResult(item, CheckStatus.FAIL, actual, expected,
                               f"存在空口令账户 {empty}，存在严重风险，请立即设置口令或锁定。",
                               os_target=self.target_os)
        return CheckResult(item, CheckStatus.PASS, actual, expected,
                           "未发现空口令账户。", os_target=self.target_os)

    def _chk_ac_b(self, item: CheckItem) -> CheckResult:
        passwd = _read_file("/etc/passwd")
        uid0 = []
        if passwd:
            for line in passwd.splitlines():
                parts = line.split(":")
                if len(parts) >= 3 and parts[2] == "0":
                    uid0.append(parts[0])
        actual = f"UID=0 账户: {', '.join(uid0)}"
        expected = "UID=0 账户仅 root"
        if uid0 == ["root"] or uid0 == ["root", "root"]:
            return CheckResult(item, CheckStatus.PASS, actual, expected,
                               "仅 root 拥有 UID=0。", os_target=self.target_os)
        extra = [u for u in uid0 if u != "root"]
        if extra:
            return CheckResult(item, CheckStatus.FAIL, actual, expected,
                               f"存在多余 UID=0 账户 {extra}，请立即移除其root权限。",
                               os_target=self.target_os)
        return CheckResult(item, CheckStatus.PASS, actual, expected,
                           "未发现多余 UID=0 账户。", os_target=self.target_os)

    def _chk_ac_c(self, item: CheckItem) -> CheckResult:
        shadow = _read_file("/etc/shadow")
        hashes = {}
        dup = []
        if shadow:
            for line in shadow.splitlines():
                parts = line.split(":")
                if len(parts) < 2:
                    continue
                user, h = parts[0], parts[1]
                if h in ("", "!", "*", "!!", "x"):
                    continue
                if h in hashes:
                    dup.append(f"{hashes[h]}={user}")
                else:
                    hashes[h] = user
        actual = f"共享口令账户对: {', '.join(dup) if dup else '无'}"
        expected = "各账户口令独立，无重复哈希"
        if dup:
            return CheckResult(item, CheckStatus.WARN, actual, expected,
                               "检测到重复口令哈希（共享口令），建议为各账户设置独立口令。",
                               os_target=self.target_os)
        return CheckResult(item, CheckStatus.PASS, actual, expected,
                           "未发现重复口令哈希。", os_target=self.target_os)

    def _chk_ac_d(self, item: CheckItem) -> CheckResult:
        files = ["/etc/sudoers"] + sorted(
            [os.path.join("/etc/sudoers.d", f)
             for f in os.listdir("/etc/sudoers.d")] if os.path.isdir("/etc/sudoers.d") else [])
        content = ""
        for f in files:
            t = _read_file(f)
            if t:
                content += t + "\n"
        # 去除注释行
        lines = [l.strip() for l in content.splitlines()
                 if l.strip() and not l.strip().startswith("#")]
        nopasswd = [l for l in lines if "NOPASSWD" in l.upper()]
        actual = f"NOPASSWD 规则数: {len(nopasswd)}"
        expected = "无宽泛的 NOPASSWD 授权"
        if nopasswd:
            return CheckResult(item, CheckStatus.WARN, actual, expected,
                               "检测到 NOPASSWD 免密 sudo 规则，请评估是否必要并收紧：\n" +
                               "\n".join(nopasswd[:5]),
                               os_target=self.target_os)
        return CheckResult(item, CheckStatus.PASS, actual, expected,
                           "未发现宽泛的免密 sudo 授权。", os_target=self.target_os)

    def _chk_ac_e(self, item: CheckItem) -> CheckResult:
        files = ["/etc/sudoers"] + sorted(
            [os.path.join("/etc/sudoers.d", f)
             for f in os.listdir("/etc/sudoers.d")] if os.path.isdir("/etc/sudoers.d") else [])
        content = ""
        for f in files:
            t = _read_file(f)
            if t:
                content += t + "\n"
        lines = [l.strip() for l in content.splitlines()
                 if l.strip() and not l.strip().startswith("#")]
        risky = [l for l in lines if re.search(r"(shutdown|reboot|poweroff|halt)", l, re.I)
                 and ("ALL" in l or "%users" in l or "%sudo" in l)]
        actual = f"宽泛关机授权规则数: {len(risky)}"
        expected = "关机/重启特权仅限管理员"
        if risky:
            return CheckResult(item, CheckStatus.WARN, actual, expected,
                               "sudoers 中将关机/重启宽泛授权给普通用户组，建议收紧：\n" +
                               "\n".join(risky[:5]), os_target=self.target_os)
        return CheckResult(item, CheckStatus.PASS, actual, expected,
                           "未将关机/重启特权宽泛授予普通用户。", os_target=self.target_os)

    def _chk_ac_f(self, item: CheckItem) -> CheckResult:
        files = ["/etc/sudoers"] + sorted(
            [os.path.join("/etc/sudoers.d", f)
             for f in os.listdir("/etc/sudoers.d")] if os.path.isdir("/etc/sudoers.d") else [])
        content = ""
        for f in files:
            t = _read_file(f)
            if t:
                content += t + "\n"
        lines = [l.strip() for l in content.splitlines()
                 if l.strip() and not l.strip().startswith("#")]
        # 授予全体用户 (ALL) 的 sudo 规则（排除已带命令限定的 NOPASSWD 行单独评估）
        grant_all = [l for l in lines if re.search(r"^\s*ALL\s+ALL\s*=", l) or
                     re.search(r"^\s*%\w+\s+ALL\s*=\s*\(ALL\)\s*ALL", l)]
        # 仅当授权对象为 ALL（所有人）视为过宽
        too_broad = [l for l in lines if re.match(r"^\s*ALL\s+ALL\s*=", l)]
        actual = f"授予 ALL 的 sudo 规则数: {len(too_broad)}"
        expected = "sudo 授权限定到专用管理员组（如 %wheel），不授予 ALL"
        if too_broad:
            return CheckResult(item, CheckStatus.WARN, actual, expected,
                               "sudo 授予了全体用户（ALL），建议限定到专用管理员组：\n" +
                               "\n".join(too_broad[:5]), os_target=self.target_os)
        return CheckResult(item, CheckStatus.PASS, actual, expected,
                           "sudo 授权已最小化，未授予全体用户。", os_target=self.target_os)

    def _chk_ac_g(self, item: CheckItem) -> CheckResult:
        smb = _read_file("/etc/samba/smb.conf")
        if smb is None:
            # Samba 未安装
            return CheckResult(item, CheckStatus.INFO,
                               "未检测到 Samba 配置（未安装或未使用）",
                               "关闭 Samba 匿名/guest 共享",
                               "本机未安装或未使用 Samba 文件共享，不适用。如已部署请确认 guest ok=no。",
                               os_target=self.target_os)
        guest = re.search(r"guest\s*ok\s*=\s*yes", smb, re.I)
        mapguest = re.search(r"map\s*to\s*guest\s*=\s*.*bad\s*user", smb, re.I)
        actual = f"guest ok={'存在' if guest else '否'}, map to guest={'存在' if mapguest else '否'}"
        expected = "guest ok=no，不映射匿名访客"
        if guest or mapguest:
            return CheckResult(item, CheckStatus.FAIL, actual, expected,
                               "Samba 开启了匿名/guest 共享，存在未授权访问风险，请设置 guest ok=no。",
                               os_target=self.target_os)
        return CheckResult(item, CheckStatus.PASS, actual, expected,
                           "Samba 未开启匿名共享。", os_target=self.target_os)

    # ---- 安全审计 ----
    def _chk_au_a(self, item: CheckItem) -> CheckResult:
        active = _svc_active("auditd")
        if active is True:
            return CheckResult(item, CheckStatus.PASS, "auditd 运行中",
                               "auditd 服务运行", "审计服务正常。", os_target=self.target_os)
        if active is False:
            return CheckResult(item, CheckStatus.WARN, "auditd 未运行",
                               "auditd 服务运行",
                               "auditd 未运行，建议 `systemctl start auditd` 并启用。",
                               os_target=self.target_os)
        return CheckResult(item, CheckStatus.FAIL, "未安装 auditd（或不可达）",
                           "auditd 服务运行",
                           "未检测到 auditd 服务，建议安装 auditd 并启用审计。",
                           os_target=self.target_os)

    def _chk_au_b(self, item: CheckItem) -> CheckResult:
        out, _, _ = _run("auditctl -l", timeout=15)
        if "permission denied" in out.lower() or "Permission denied" in out:
            return CheckResult(item, CheckStatus.INFO, "无权限读取审计规则",
                               "审计规则覆盖关键文件",
                               "当前用户无权限读取 audit 规则（需 root）。如已配置关键文件审计规则，请补充证据。",
                               os_target=self.target_os)
        has_rules = bool(out.strip())
        has_key = any(k in out for k in ("passwd", "shadow", "ssh", "/etc"))
        actual = f"审计规则: {'有' if has_rules else '无'}" + (f"（覆盖关键文件:{'是' if has_key else '否'}）" if has_rules else "")
        expected = "审计规则覆盖 /etc/passwd、/etc/shadow、/etc/ssh 等关键文件"
        if has_rules and has_key:
            return CheckResult(item, CheckStatus.PASS, actual, expected,
                               "审计规则已覆盖关键文件。", os_target=self.target_os)
        if has_rules:
            return CheckResult(item, CheckStatus.WARN, actual, expected,
                               "存在审计规则但未覆盖全部关键文件，建议补充。", os_target=self.target_os)
        return CheckResult(item, CheckStatus.WARN, actual, expected,
                           "未发现审计规则，建议通过 auditctl 添加关键文件审计规则。",
                           os_target=self.target_os)

    def _chk_au_c(self, item: CheckItem) -> CheckResult:
        issues = []
        d = "/var/log/audit"
        if os.path.isdir(d):
            st = os.stat(d)
            mode = oct(st.st_mode & 0o777)
            if mode not in ("0o700", "0o750", "0o710"):
                issues.append(f"审计目录权限={mode}(建议700)")
        else:
            issues.append("审计目录不存在")
        conf = _read_file("/etc/audit/auditd.conf")
        max_file = None
        num_logs = None
        if conf:
            for line in conf.splitlines():
                if line.strip().startswith("max_log_file "):
                    max_file = line.strip().split()[-1]
                if line.strip().startswith("num_logs "):
                    num_logs = line.strip().split()[-1]
        actual = f"目录权限={'存在' if os.path.isdir(d) else '缺失'}, max_log_file={max_file}, num_logs={num_logs}"
        expected = "审计日志权限受限(700)，配置日志大小与轮转"
        if issues:
            return CheckResult(item, CheckStatus.WARN, actual, expected,
                               "审计日志保护不足：" + "；".join(issues), os_target=self.target_os)
        return CheckResult(item, CheckStatus.PASS, actual, expected,
                           "审计日志保护与留存配置正常。", os_target=self.target_os)

    def _chk_au_d(self, item: CheckItem) -> CheckResult:
        enabled = _svc_enabled("auditd")
        if enabled is True:
            return CheckResult(item, CheckStatus.PASS, "auditd 开机自启",
                               "auditd 开机自启", "审计服务开机自启。", os_target=self.target_os)
        if enabled is False:
            return CheckResult(item, CheckStatus.WARN, "auditd 未开机自启",
                               "auditd 开机自启", "建议 `systemctl enable auditd`。",
                               os_target=self.target_os)
        return CheckResult(item, CheckStatus.INFO, "无法确认 auditd 自启状态",
                           "auditd 开机自启",
                           "未检测到 auditd 服务，无法确认自启状态，需补充证据。",
                           os_target=self.target_os)

    # ---- 入侵防范 ----
    def _chk_ip_a(self, item: CheckItem) -> CheckResult:
        risky = ["telnet.socket", "rsh.socket", "rlogin.socket", "rlogin",
                 "telnet", "vsftpd", "tftp", "rsh", "rexec"]
        out, _, _ = _run("systemctl list-unit-files --type=service --state=enabled", timeout=20)
        enabled = out.lower()
        found = [s for s in risky if s.lower() in enabled]
        actual = f"已启用的高危服务: {', '.join(found) if found else '无'}"
        expected = "未启用 telnet/rsh/rlogin/tftp/vsftpd 等高危服务"
        if found:
            return CheckResult(item, CheckStatus.FAIL, actual, expected,
                               f"检测到高危服务 {found} 已启用，建议关闭并卸载。",
                               os_target=self.target_os)
        return CheckResult(item, CheckStatus.PASS, actual, expected,
                           "未发现已启用的高危网络服务。", os_target=self.target_os)

    def _chk_ip_b(self, item: CheckItem) -> CheckResult:
        issues = []
        # NFS
        if _svc_active("nfs-server") or _svc_active("nfs-kernel-server"):
            exports = _read_file("/etc/exports")
            if exports and "*(rw" in exports.replace(" ", ""):
                issues.append("NFS 存在宽泛可写共享")
        # Samba
        smb = _read_file("/etc/samba/smb.conf")
        if smb and re.search(r"writable\s*=\s*yes", smb, re.I):
            issues.append("Samba 存在可写共享")
        actual = f"发现风险共享: {', '.join(issues) if issues else '无'}"
        expected = "不暴露不必要的可写网络共享"
        if issues:
            return CheckResult(item, CheckStatus.WARN, actual, expected,
                               "存在不必要的网络文件共享：" + "；".join(issues) +
                               "，建议关闭或严格限制来源。", os_target=self.target_os)
        return CheckResult(item, CheckStatus.PASS, actual, expected,
                           "未发现不必要的可写网络共享。", os_target=self.target_os)

    def _chk_ip_c(self, item: CheckItem) -> CheckResult:
        out, _, _ = _run("ss -tulnp", timeout=15)
        bad_ports = {"23": "telnet", "512": "exec", "513": "login", "514": "shell/rwho"}
        found = []
        for line in out.splitlines():
            m = re.search(r":(\d+)\s", line)
            if m and m.group(1) in bad_ports:
                found.append(f"{bad_ports[m.group(1)]}({m.group(1)})")
        actual = f"不安全监听端口: {', '.join(found) if found else '无'}"
        expected = "不监听 telnet(23)/rservices(512-514) 等不安全端口"
        if found:
            return CheckResult(item, CheckStatus.FAIL, actual, expected,
                               f"检测到不安全端口监听 {found}，请关闭对应服务。",
                               os_target=self.target_os)
        return CheckResult(item, CheckStatus.PASS, actual, expected,
                           "未发现不安全端口监听。", os_target=self.target_os)

    def _chk_ip_d(self, item: CheckItem) -> CheckResult:
        # 优先 apt，其次 dnf/yum
        out, _, rc = _run("apt list --upgradable 2>/dev/null", timeout=40)
        pending = 0
        if rc == 0 and "upgradable" in out:
            pending = sum(1 for l in out.splitlines() if "upgradable" in l)
        else:
            out2, _, rc2 = _run("dnf check-update 2>/dev/null || yum check-update 2>/dev/null", timeout=60)
            if rc2 == 0 and out2:
                pending = len([l for l in out2.splitlines()
                               if re.match(r"^[\w\-]+\\.[\w]+\s", l)])
        actual = f"待安装更新数: {pending}"
        expected = "及时安装安全更新"
        if pending == 0:
            return CheckResult(item, CheckStatus.PASS, actual, expected,
                               "系统已是最新或无可升级包。", os_target=self.target_os)
        return CheckResult(item, CheckStatus.WARN, actual, expected,
                           f"存在 {pending} 个待安装更新，建议及时安全更新。",
                           os_target=self.target_os)

    def _chk_ip_e(self, item: CheckItem) -> CheckResult:
        syncookies = _read_file("/proc/sys/net/ipv4/tcp_syncookies")
        sync_on = syncookies and syncookies.strip() == "1"
        # 防火墙
        fw = "无"
        if _run("command -v ufw", timeout=10)[0]:
            fw_out, _, _ = _run("ufw status", timeout=10)
            fw = "ufw: " + ("启用" if "active" in fw_out.lower() else "未启用")
        elif _run("command -v nft", timeout=10)[0]:
            fw = "nftables: 存在"
        elif _run("command -v iptables", timeout=10)[0]:
            fw = "iptables: 存在"
        actual = f"tcp_syncookies={'开启' if sync_on else '关闭'}, 防火墙={fw}"
        expected = "tcp_syncookies=1 且启用主机防火墙"
        if sync_on and "启用" in fw:
            return CheckResult(item, CheckStatus.PASS, actual, expected,
                               "SYN 防护与防火墙均已启用。", os_target=self.target_os)
        issues = []
        if not sync_on:
            issues.append("tcp_syncookies 未开启")
        if "未启用" in fw or fw == "无":
            issues.append("未启用主机防火墙")
        return CheckResult(item, CheckStatus.WARN, actual, expected,
                           "网络攻击防护待加强：" + "；".join(issues) + "。",
                           os_target=self.target_os)

    # ---- 恶意代码防范 ----
    def _chk_mc_a(self, item: CheckItem) -> CheckResult:
        tools = []
        for cmd in ("clamscan", "clamd", "rkhunter", "chkrootkit", "sophosav"):
            if _run(f"command -v {cmd}", timeout=10)[0]:
                tools.append(cmd)
        actual = f"已部署防护: {', '.join(tools) if tools else '无'}"
        expected = "部署 ClamAV / rkhunter / chkrootkit 等恶意代码防护"
        if tools:
            return CheckResult(item, CheckStatus.PASS, actual, expected,
                               "已部署恶意代码防护工具。", os_target=self.target_os)
        return CheckResult(item, CheckStatus.WARN, actual, expected,
                           "未检测到恶意代码防护工具，建议部署 ClamAV 并定期更新病毒库。",
                           os_target=self.target_os)

    # ---- 可信验证 ----
    def _chk_tv_a(self, item: CheckItem) -> CheckResult:
        sb_out, _, _ = _run("mokutil --sb-state 2>/dev/null", timeout=15)
        sb_enabled = "SecureBoot enabled" in sb_out
        tpm = os.path.isdir("/sys/class/tpm") and bool(os.listdir("/sys/class/tpm"))
        actual = f"SecureBoot={'启用' if sb_enabled else '未启用/不可用'}, TPM={'存在' if tpm else '不存在'}"
        expected = "启用 Secure Boot 与 TPM，构建可信启动链"
        if sb_enabled:
            return CheckResult(item, CheckStatus.PASS, actual, expected,
                               "已启用 Secure Boot，具备基础可信启动能力。",
                               os_target=self.target_os)
        if tpm:
            return CheckResult(item, CheckStatus.WARN, actual, expected,
                               "检测到 TPM 但 Secure Boot 未启用，建议启用 Secure Boot 完善可信链。",
                               os_target=self.target_os)
        return CheckResult(item, CheckStatus.INFO, actual, expected,
                           "未检测到 Secure Boot/TPM（可能为虚拟机或老旧硬件）。如硬件支持请启用，否则需补充可信验证证据。",
                           os_target=self.target_os)


def quick_check(target_os: str = "linux") -> Dict:
    """便捷入口：运行全部检查并返回 summary + system_info。"""
    checker = LinuxBaselineChecker(target_os=target_os)
    results = checker.run_all()
    return {
        "summary": checker.get_summary(),
        "system_info": checker.get_system_info_dict(),
        "check_results": [r.to_dict() for r in results],
    }


if __name__ == "__main__":
    import json
    data = quick_check()
    print(json.dumps(data["summary"], ensure_ascii=False, indent=2))
