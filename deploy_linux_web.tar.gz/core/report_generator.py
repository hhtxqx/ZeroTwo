# -*- coding: utf-8 -*-
"""
HTML 报告生成器

根据安全基线检查结果和 AI 分析内容，生成符合国家等保要求的 HTML 格式报告。
包含执行摘要、八大章节正文、原始证据附录。
使用优雅的内联 CSS 排版，确保企业级专业文档效果。

Author: Zero Two Team
"""

import os
import json
import shutil
from datetime import datetime
from typing import Dict, List, Optional

from utils.paths import project_root


class ReportGenerator:
    """
    HTML 格式等保检查报告生成器

    将结构化的检查结果转换为排版精美、内容完整的 HTML 报告文档。
    支持嵌入 AI 分析内容和证据文件链接。

    Usage::
        gen = ReportGenerator()
        html = gen.generate(
            system_info={...},
            check_results=[...],
            summary={...},
            ai_analysis="...",
            evidence_dir="./evidence",
        )
        gen.save(html, output_path="reports/win11_20260718_223930.html")
    """

    # ===== EVA 二号机配色方案 =====
    COLOR_PRIMARY = "#E84A22"      # 主色 - 明日香红
    COLOR_SECONDARY = "#F59E0B"    # 辅助色 - EVA橙
    COLOR_DARK = "#1A1A2E"         # 深色背景
    COLOR_DARKER = "#12121F"       # 更深背景
    COLOR_TEXT = "#E8E8E8"         # 正文文字
    COLOR_TEXT_LIGHT = "#A0A0B0"   # 次要文字

    # 等保六大控制域（雷达图 / 对比页固定顺序）
    CATEGORY_ORDER = [
        "身份鉴别", "访问控制", "安全审计",
        "入侵防范", "恶意代码防范", "可信验证",
    ]

    # 合规率计分权重：通过=1.0，警告=0.5，其余不计入分子
    _SCORE_WEIGHTS = {"通过": 1.0, "警告": 0.5, "不通过": 0.0, "错误": 0.0, "信息": 0.0}
    COLOR_SUCCESS = "#22C55E"      # 通过绿
    COLOR_DANGER = "#EF4444"       # 不通过红
    COLOR_WARNING = "#F59E0B"      # 警告黄
    COLOR_INFO = "#3B82F6"         # 信息蓝
    COLOR_BORDER = "#2A2A3E"       # 边框色
    COLOR_CARD_BG = "#16162A"      # 卡片背景

    def __init__(self, report_dir: str = "", platform_name: str = "Windows"):
        """
        初始化报告生成器

        Args:
            report_dir: 报告存储目录
            platform_name: 平台名称（默认 "Windows"），用于报告头部/页脚标题。
                            Linux Web 版传入 "Linux" 即可复用同一套 EVA 风格排版。
        """
        # HTML 报告统一存放到 reports/HTML/ 子目录（与 Word/PDF 子目录并列）
        self.report_dir = report_dir or os.path.join(project_root(), "reports", "HTML")
        os.makedirs(self.report_dir, exist_ok=True)
        self.platform_name = platform_name

    @staticmethod
    def _escape_html(text: str) -> str:
        """HTML 特殊字符转义"""
        return (text
                .replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace('"', "&quot;"))

    def _generate_css(self) -> str:
        """生成内联 CSS 样式"""
        return f"""
        <style>
            * {{ margin: 0; padding: 0; box-sizing: border-box; }}
            body {{
                font-family: 'Segoe UI', 'Microsoft YaHei', 'PingFang SC', sans-serif;
                background: {self.COLOR_DARK};
                color: {self.COLOR_TEXT};
                line-height: 1.8;
                font-size: 14px;
                padding: 20px;
            }}

            /* ===== 报告头部 ===== */
            .report-header {{
                background: linear-gradient(135deg, {self.COLOR_PRIMARY}11, {self.COLOR_SECONDARY}11);
                border-left: 4px solid {self.COLOR_PRIMARY};
                padding: 30px 40px;
                margin-bottom: 30px;
                border-radius: 0 12px 12px 0;
            }}
            .report-header h1 {{
                font-size: 28px;
                color: {self.COLOR_PRIMARY};
                margin-bottom: 12px;
                letter-spacing: 2px;
            }}
            .report-header .meta {{
                display: flex;
                flex-wrap: wrap;
                gap: 20px;
                color: {self.COLOR_TEXT_LIGHT};
                font-size: 13px;
            }}
            .report-header .meta span {{
                background: {self.COLOR_CARD_BG};
                padding: 4px 14px;
                border-radius: 20px;
                border: 1px solid {self.COLOR_BORDER};
            }}

            /* ===== 章节标题 ===== */
            .section {{
                margin-bottom: 35px;
            }}
            .section-title {{
                font-size: 20px;
                color: {self.COLOR_SECONDARY};
                padding: 12px 24px;
                background: {self.COLOR_CARD_BG};
                border-left: 4px solid {self.COLOR_SECONDARY};
                border-radius: 0 8px 8px 0;
                margin-bottom: 20px;
                display: flex;
                align-items: center;
                gap: 10px;
            }}
            .section-title .num {{
                background: {self.COLOR_SECONDARY};
                color: {self.COLOR_DARK};
                width: 32px;
                height: 32px;
                border-radius: 50%;
                display: flex;
                align-items: center;
                justify-content: center;
                font-weight: bold;
                font-size: 14px;
            }}

            /* ===== 统计卡片 ===== */
            .stats-grid {{
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
                gap: 16px;
                margin-bottom: 25px;
            }}
            .stat-card {{
                background: {self.COLOR_CARD_BG};
                border: 1px solid {self.COLOR_BORDER};
                border-radius: 10px;
                padding: 20px;
                text-align: center;
            }}
            .stat-card .value {{
                font-size: 36px;
                font-weight: bold;
                margin-bottom: 6px;
            }}
            .stat-card .label {{
                color: {self.COLOR_TEXT_LIGHT};
                font-size: 13px;
            }}
            .stat-total .value {{ color: {self.COLOR_INFO}; }}
            .stat-pass .value {{ color: {self.COLOR_SUCCESS}; }}
            .stat-fail .value {{ color: {self.COLOR_DANGER}; }}
            .stat-warn .value {{ color: {self.COLOR_WARNING}; }}
            .stat-error .value {{ color: {self.COLOR_TEXT_LIGHT}; }}

            /* ===== 检查结果表格 ===== */
            .result-table {{
                width: 100%;
                border-collapse: collapse;
                background: {self.COLOR_CARD_BG};
                border-radius: 10px;
                overflow: hidden;
                box-shadow: 0 2px 12px rgba(0,0,0,0.3);
            }}
            .result-table thead {{
                background: {self.COLOR_DARKER};
            }}
            .result-table th {{
                padding: 14px 16px;
                text-align: left;
                font-weight: 600;
                color: {self.COLOR_SECONDARY};
                font-size: 13px;
                border-bottom: 2px solid {self.COLOR_BORDER};
                white-space: nowrap;
            }}
            .result-table td {{
                padding: 12px 16px;
                border-bottom: 1px solid {self.COLOR_BORDER};
                vertical-align: top;
                font-size: 13px;
            }}
            .result-table tr:hover td {{
                background: rgba(232,74,34,0.05);
            }}
            .badge {{
                display: inline-block;
                padding: 3px 10px;
                border-radius: 12px;
                font-size: 12px;
                font-weight: 600;
            }}
            .badge-pass {{ background: rgba(34,197,94,0.15); color: {self.COLOR_SUCCESS}; }}
            .badge-fail {{ background: rgba(239,68,68,0.15); color: {self.COLOR_DANGER}; }}
            .badge-warn {{ background: rgba(245,158,11,0.15); color: {self.COLOR_WARNING}; }}
            .badge-info {{ background: rgba(59,130,246,0.15); color: {self.COLOR_INFO}; }}
            .badge-error {{ background: rgba(100,100,120,0.15); color: {self.COLOR_TEXT_LIGHT}; }}
            .badge-high {{ background: rgba(239,68,68,0.2); color: #FF6B6B; }}
            .badge-mid {{ background: rgba(245,158,11,0.2); color: {self.COLOR_SECONDARY}; }}
            .badge-low {{ background: rgba(34,197,94,0.2); color: {self.COLOR_SUCCESS}; }}

            /* ===== AI 分析区域 ===== */
            .ai-analysis {{
                background: {self.COLOR_CARD_BG};
                border: 1px solid {self.COLOR_BORDER};
                border-radius: 12px;
                padding: 30px;
                line-height: 2;
            }}
            .ai-analysis h3 {{
                color: {self.COLOR_PRIMARY};
                margin: 20px 0 10px 0;
                font-size: 17px;
            }}
            .ai-analysis h2 {{
                color: {self.COLOR_SECONDARY};
                margin: 25px 0 12px 0;
                font-size: 20px;
                border-bottom: 1px solid {self.COLOR_BORDER};
                padding-bottom: 8px;
            }}
            .ai-analysis p, .ai-analysis li {{
                margin-bottom: 8px;
            }}
            .ai-analysis ul, .ai-analysis ol {{
                padding-left: 24px;
            }}
            .ai-analysis strong {{
                color: {self.COLOR_SECONDARY};
            }}
            .ai-analysis blockquote {{
                border-left: 3px solid {self.COLOR_PRIMARY};
                margin: 12px 0;
                padding: 10px 20px;
                background: rgba(232,74,34,0.05);
                border-radius: 0 8px 8px 0;
                color: {self.COLOR_TEXT_LIGHT};
            }}
            .ai-analysis table {{
                width: 100%;
                border-collapse: collapse;
                margin: 12px 0;
                font-size: 13px;
            }}
            .ai-analysis th, .ai-analysis td {{
                border: 1px solid {self.COLOR_BORDER};
                padding: 8px 12px;
                text-align: left;
            }}
            .ai-analysis th {{
                background: {self.COLOR_DARKER};
                color: {self.COLOR_SECONDARY};
            }}

            /* ===== 证据附录 ===== */
            .evidence-list {{
                list-style: none;
            }}
            .evidence-list li {{
                background: {self.COLOR_CARD_BG};
                border: 1px solid {self.COLOR_BORDER};
                padding: 10px 18px;
                margin-bottom: 8px;
                border-radius: 6px;
                font-family: 'Consolas', monospace;
                font-size: 13px;
                color: {self.COLOR_TEXT_LIGHT};
            }}

            /* ===== 页脚 ===== */
            .report-footer {{
                text-align: center;
                padding: 30px;
                color: {self.COLOR_TEXT_LIGHT};
                font-size: 12px;
                border-top: 1px solid {self.COLOR_BORDER};
                margin-top: 40px;
            }}
            .report-footer .brand {{
                color: {self.COLOR_PRIMARY};
                font-weight: bold;
                font-size: 16px;
                margin-bottom: 8px;
            }}

            /* ===== 响应式 ===== */
            @media print {{
                body {{ background: white; color: #222; padding: 0; }}
                .report-header {{ background: #f5f5f5; border-color: #E84A22; }}
                .section-title {{ background: #f5f5f5; border-color: #F59E0B; color: #333; }}
                .stat-card, .result-table, .ai-analysis {{
                    background: white;
                    border-color: #ddd;
                }}
                .badge-pass {{ background: #d4edda; color: #155724; }}
                .badge-fail {{ background: #f8d7da; color: #721c24; }}
            }}
            @media (max-width: 768px) {{
                .stats-grid {{ grid-template-columns: repeat(2, 1fr); }}
                .result-table {{ font-size: 12px; }}
                .result-table th, .result-table td {{ padding: 8px 10px; }}
            }}
        </style>
        """

    def _render_header(self, info: Dict) -> str:
        """渲染报告头部"""
        return f"""
        <div class="report-header">
            <h1>Zero Two — {self.platform_name} 安全基线检查报告</h1>
            <div class="meta">
                <span>目标主机: {self._escape_html(info.get('hostname', 'N/A'))}</span>
                <span>操作系统: {self._escape_html(info.get('os_version', 'N/A'))}</span>
                <span>架构: {self._escape_html(info.get('architecture', 'N/A'))}</span>
                <span>检查时间: {self._escape_html(info.get('check_time', 'N/A'))}</span>
                <span>检查员: {self._escape_html(info.get('username', 'N/A'))}</span>
                <span>报告生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</span>
            </div>
        </div>
        """

    def _render_summary(self, summary: Dict, ai_verdict: str = "") -> str:
        """渲染执行摘要"""
        total = summary.get("total", 0)
        pass_count = summary.get("通过", 0)
        fail_count = summary.get("不通过", 0)
        warn_count = summary.get("警告", 0)
        error_count = summary.get("错误", 0)
        high_risk = summary.get("high_risk_failures", 0)

        # 合规判定
        if fail_count == 0 and high_risk == 0:
            verdict = "符合基本要求"
            verdict_color = self.COLOR_SUCCESS
        elif fail_count <= 3 and high_risk == 0:
            verdict = "部分符合"
            verdict_color = self.COLOR_WARNING
        else:
            verdict = "不符合（存在重大风险）"
            verdict_color = self.COLOR_DANGER

        html = f"""
        <div class="section">
            <div class="section-title"><span class="num">0</span> 执行摘要</div>

            <div class="stats-grid">
                <div class="stat-card stat-total"><div class="value">{total}</div><div class="label">总检查项</div></div>
                <div class="stat-card stat-pass"><div class="value">{pass_count}</div><div class="label">通过</div></div>
                <div class="stat-card stat-fail"><div class="value">{fail_count}</div><div class="label">不通过</div></div>
                <div class="stat-card stat-warn"><div class="value">{warn_count}</div><div class="label">警告</div></div>
                <div class="stat-card stat-error"><div class="value">{error_count}</div><div class="label">检测异常</div></div>
                <div class="stat-card"><div class="value" style="color:{verdict_color}">{'是' if high_risk > 0 else '否'}</div><div class="label">重大风险隐患</div></div>
            </div>

            <p style="margin-bottom:12px;color:{self.COLOR_TEXT_LIGHT}">
                <strong>整体合规判定：</strong>
                <span style="color:{verdict_color};font-size:18px;font-weight:bold;margin-left:8px;">{verdict}</span>
            </p>
            {f'<p style="color:{self.COLOR_TEXT_LIGHT}"><strong>AI 智能研判：</strong>{self._escape_html(ai_verdict)}</p>' if ai_verdict else ''}
        </div>
        """
        return html

    def _render_detail_table(self, results: List[Dict]) -> str:
        """渲染检查结果明细表格"""
        rows = ""
        for r in results:
            rid = self._escape_html(str(r.get('id', '')))
            name = self._escape_html(str(r.get('name', '')))
            cat = self._escape_html(str(r.get('category', '')))
            status = self._escape_html(str(r.get('status', '')))
            risk = self._escape_html(str(r.get('risk_level', '')))
            actual = self._escape_html(str(r.get('actual_value', ''))[:150])
            expected = self._escape_html(str(r.get('expected_value', ''))[:80])
            detail = self._escape_html(str(r.get('detail', ''))[:200])
            remediation = self._escape_html(str(r.get('remediation', ''))[:200])

            status_class = {"通过": "pass", "不通过": "fail", "警告": "warn", "信息": "info", "错误": "error"}.get(status, "info")
            risk_class = {"高": "high", "中": "mid", "低": "low"}.get(risk, "mid")

            rows += f"""
            <tr>
                <td><strong>{rid}</strong></td>
                <td>{name}</td>
                <td>{cat}</td>
                <td><span class="badge badge-{status_class}">{status}</span></td>
                <td><span class="badge badge-{risk_class}">{risk}</span></td>
                <td style="font-size:12px">{actual or '-'}</td>
                <td style="font-size:12px">{expected or '-'}</td>
                <td title="{detail}">{detail[:60] or '-'}</td>
                <td title="{remediation}">{remediation[:60] or '-'}</td>
            </tr>
            """

        return f"""
        <div class="section">
            <div class="section-title"><span class="num">1</span> 检查结果明细</div>
            <div style="overflow-x:auto;">
                <table class="result-table">
                    <thead>
                        <tr>
                            <th>#</th><th>检查项名称</th><th>类别</th><th>状态</th>
                            <th>风险</th><th>当前值</th><th>期望值</th>
                            <th>详情</th><th>整改建议</th>
                        </tr>
                    </thead>
                    <tbody>{rows}</tbody>
                </table>
            </div>
        </div>
        """

    def _render_ai_section(self, ai_content: str) -> str:
        """渲染 AI 分析章节"""
        if not ai_content.strip():
            return ""

        # 将 Markdown 风格的内容简单转为 HTML
        content = self._escape_html(ai_content)
        # 基础 Markdown 转 HTML
        import re
        # 标题
        for level in range(6, 0, -1):
            pattern = '^' + '#' * level + ' (.+)$'
            content = re.sub(pattern, rf'<h{level}>\1</h{level}>', content, flags=re.MULTILINE)
        # 粗体
        content = re.sub(r'\*\*(.+?)\*\*', r'<strong>\1</strong>', content)
        # 斜体
        content = re.sub(r'\*(.+?)\*', r'<em>\1</em>', content)
        # 行内代码
        content = re.sub(r'`(.+?)`', r'<code style="background:#2a2a3e;padding:2px 6px;border-radius:4px;font-size:12px;">\1</code>', content)
        # 无序列表
        content = re.sub(r'^[\-\*] (.+)$', r'<li>\1</li>', content, flags=re.MULTILINE)
        content = re.sub(r'(<li>.*</li>\n?)+', r'<ul>\g<0></ul>', content)
        # 有序列表
        content = re.sub(r'^(\d+)\. (.+)$', r'<li>\2</li>', content, flags=re.MULTILINE)
        # 引用块
        content = re.sub(r'^&gt; (.+)$', r'<blockquote>\1</blockquote>', content, flags=re.MULTILINE)
        # 分隔线
        content = re.sub(r'^---+$', r'<hr style="border:none;border-top:1px solid {self.COLOR_BORDER};margin:16px 0;">', content, flags=re.MULTILINE)
        # 段落
        paragraphs = content.split('\n\n')
        content = '\n'.join(f'<p>{p}</p>' if not p.startswith('<') and p.strip() else p for p in paragraphs)

        return f"""
        <div class="section">
            <div class="section-title"><span class="num">2</span> AI 智能分析与整改建议</div>
            <div class="ai-analysis">
                {content}
            </div>
        </div>
        """

    def _render_evidence_appendix(self, all_evidence: List[str]) -> str:
        """渲染原始证据附录"""
        if not all_evidence:
            return f'<p style="color:{self.COLOR_TEXT_LIGHT}">本次检查未导出额外证据文件。</p>'

        items = ""
        for ev in all_evidence:
            filename = os.path.basename(ev)
            items += f"<li><code>{self._escape_html(filename)}</code></li>"

        return f"""
        <div class="section">
            <div class="section-title"><span class="num">A</span> 原始证据附录</div>
            <p style="color:{self.COLOR_TEXT_LIGHT};margin-bottom:12px;">
                以下为检查过程中自动采集的关键注册表快照及配置证据文件：
            </p>
            <ul class="evidence-list">{items}</ul>
        </div>
        """

    def _render_footer(self) -> str:
        """渲染页脚"""
        return f"""
        <div class="report-footer">
            <div class="brand">Zero Two v2.0 — 中国辽宁沈阳好果汁股份有限公司</div>
            <p>本报告由 Zero Two {self.platform_name} 安全基线自动检查工具生成</p>
            <p>报告仅供参考，最终合规判定需结合人工审核与实际业务场景综合判断</p>
            <p style="margin-top:8px;">Generated at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>
        </div>
        """

    def generate(self,
                 system_info: Dict,
                 check_results: List[Dict],
                 summary: Dict,
                 ai_content: str = "",
                 evidence_list: List[str] = None) -> str:
        """
        生成完整 HTML 报告

        Args:
            system_info: 系统信息字典
            check_results: 检查结果列表（to_dict 格式）
            summary: 摘要统计
            ai_content: AI 分析内容（Markdown 格式字符串）
            evidence_list: 证据文件绝对路径列表

        Returns:
            完整 HTML 字符串
        """
        html_parts = [
            "<!DOCTYPE html>",
            '<html lang="zh-CN">',
            "<head>",
            '<meta charset="UTF-8">',
            '<meta name="viewport" content="width=device-width, initial-scale=1.0">',
            f"<title>ZeroTwo 安全基线检查报告 - {system_info.get('hostname', '')}</title>",
            self._generate_css(),
            "</head>",
            "<body>",
            self._render_header(system_info),
            self._render_summary(summary),
            self._render_detail_table(check_results),
            self._render_ai_section(ai_content),
            self._render_evidence_appendix(evidence_list or []),
            self._render_footer(),
            "</body>",
            "</html>",
        ]
        return "\n".join(html_parts)

    def save(self, html_content: str, filename: str = "", custom_name: str = "",
              payload: Optional[Dict] = None) -> str:
        """
        保存 HTML 报告到磁盘

        Args:
            html_content: HTML 内容
            filename: 自定义文件名（不含扩展名），为空则自动生成
            custom_name: 用户自定义的报告名称前缀
            payload: 结构化数据副档（dict），非空时同时写出同名 .json 文件，
                     供「报告对比」页读取并绘制雷达图（无需解析 HTML）

        Returns:
            保存后的文件绝对路径
        """
        if custom_name:
            base_name = custom_name
        elif filename:
            base_name = filename
        else:
            # 默认命名规则: {os_tag}_{年月日}_{时分秒}
            # config.settings 为桌面端配置模块；Linux Web 精简部署可能不含此模块，
            # 故做可选导入，缺失时按运行平台推断前缀，避免 No module named 'config'。
            os_tag = "win"
            try:
                from config.settings import get_settings
                settings = get_settings(project_root())
                os_tag = settings.get_os_version() or os_tag
            except Exception:
                pass
            # 精简部署无 config 或未取得系统版本时，按运行平台推断前缀
            if not os_tag or os_tag == "win":
                plat = (self.platform_name or "Windows").lower()
                if plat == "linux":
                    os_tag = "linux"
            ts = datetime.now().strftime("%Y%m%d_%H%M%S")
            base_name = f"{os_tag}_{ts}"

        filepath = os.path.join(self.report_dir, f"{base_name}.html")
        with open(filepath, "w", encoding="utf-8") as f:
            f.write(html_content)

        # 写出结构化数据副档（用于报告对比页）
        if payload is not None:
            json_path = os.path.splitext(filepath)[0] + ".json"
            with open(json_path, "w", encoding="utf-8") as f:
                json.dump(payload, f, ensure_ascii=False, indent=2)

        return filepath

    def build_payload(self, system_info: Dict, check_dicts: List[Dict],
                      summary: Dict, ai_content: str = "") -> Dict:
        """
        根据检查结果构建结构化数据副档（供报告对比页使用）。

        按六大控制域聚合每域的检查项数、各状态计数与合规率分数，
        并保留逐条检查项状态（用于变化项明细对比）。

        Args:
            system_info: 系统信息字典
            check_dicts: 检查结果列表（CheckResult.to_dict 格式）
            summary: 摘要统计（checker.get_summary 返回）
            ai_content: AI 分析内容（仅存是否存在的标记，不存全文以控体积）

        Returns:
            结构化字典，可直接 json.dump
        """
        # 初始化各控制域计数容器
        cats: Dict[str, Dict] = {}
        for c in self.CATEGORY_ORDER:
            cats[c] = {"total": 0, "通过": 0, "不通过": 0, "警告": 0,
                       "错误": 0, "信息": 0, "score": 0.0}
        # 未归类项（理论上不出现）也兜底
        cats["未分类"] = {"total": 0, "通过": 0, "不通过": 0, "警告": 0,
                          "错误": 0, "信息": 0, "score": 0.0}

        for r in check_dicts:
            cat = r.get("category", "未分类")
            if cat not in cats:
                cats[cat] = {"total": 0, "通过": 0, "不通过": 0, "警告": 0,
                             "错误": 0, "信息": 0, "score": 0.0}
            st = r.get("status", "")
            cats[cat]["total"] += 1
            if st in cats[cat]:
                cats[cat][st] += 1

        # 计算每域合规率分数（通过=1.0，警告=0.5，其余不计分子）
        for c, v in cats.items():
            denom = (v["通过"] + v["不通过"] + v["警告"] + v["错误"])
            if denom > 0:
                weighted = (v["通过"] * 1.0 + v["警告"] * 0.5)
                v["score"] = round(weighted / denom * 100, 1)
            else:
                v["score"] = 0.0
        # 仅保留六大域的固定顺序输出，剔除空桶「未分类」
        if "未分类" in cats and cats["未分类"]["total"] == 0:
            del cats["未分类"]

        results = [
            {
                "id": r.get("id"),
                "name": r.get("name"),
                "category": r.get("category"),
                "status": r.get("status"),
            }
            for r in check_dicts
        ]

        return {
            "generated_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "os_version": system_info.get("os_display")
                           or system_info.get("os_version")
                           or system_info.get("caption")
                           or "",
            "hostname": system_info.get("hostname", ""),
            "has_ai": bool(ai_content and ai_content.strip()),
            "summary": summary,
            "categories": cats,
            "check_results": results,
        }

    @staticmethod
    def suggest_filename() -> str:
        """
        根据当前时间和 OS 版本建议默认文件名

        Returns:
            建议的文件名（不含扩展名）
        """
        from config.settings import get_settings
        settings = get_settings()
        os_tag = settings.get_os_version() or "win"
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        return f"{os_tag}_{ts}"
