# -*- coding: utf-8 -*-
"""
配置持久化管理模块

提供全局设置的中心化存储与读取，使用 JSON 文件进行本地持久化。
支持以下配置项：
- DeepSeek API Key
- 自定义提示词（AI 分析用）
- 检查模板（用户自定义的检查项组合）
- 操作指南显示状态
- 提示词模式（默认/自定义）

Author: Zero Two Team
"""

import json
import os
from typing import Any, Optional

from utils.paths import project_root


class SettingsManager:
    """
    全局配置管理器

    所有配置项通过 JSON 文件在本地持久化存储，
    程序启动时自动加载，修改时自动保存。

    Attributes:
        config_path (str): 配置文件绝对路径
        _data (dict): 内存中的配置数据缓存
    """

    DEFAULT_CONFIG = {
        "api_key": "",
        "custom_prompt": "",
        "prompt_mode": "default",  # "default" | "custom"
        "templates": {},  # {模板名: [检查项ID列表]}
        "show_guide": True,
        "os_version": "",  # "win10" | "win11" | "win_server" | ""(自动检测)
    }

    def __init__(self, config_dir: str):
        """
        初始化配置管理器

        Args:
            config_dir: 配置文件所在目录路径
        """
        self.config_path = os.path.join(config_dir, "settings.json")
        self._data: dict = {}
        self._load()

    def _load(self) -> None:
        """从 JSON 文件加载配置到内存"""
        if os.path.exists(self.config_path):
            try:
                with open(self.config_path, "r", encoding="utf-8") as f:
                    self._data = json.load(f)
                # 合并缺失的默认值
                for key, value in self.DEFAULT_CONFIG.items():
                    if key not in self._data:
                        self._data[key] = value
            except (json.JSONDecodeError, IOError):
                self._data = self.DEFAULT_CONFIG.copy()
        else:
            self._data = self.DEFAULT_CONFIG.copy()

    def _save(self) -> None:
        """将内存中的配置保存到 JSON 文件"""
        os.makedirs(os.path.dirname(self.config_path), exist_ok=True)
        with open(self.config_path, "w", encoding="utf-8") as f:
            json.dump(self._data, f, ensure_ascii=False, indent=2)

    def get(self, key: str, default: Any = None) -> Any:
        """
        获取配置项

        Args:
            key: 配置键名
            default: 键不存在时的默认返回值

        Returns:
            配置值或默认值
        """
        return self._data.get(key, default)

    def set(self, key: str, value: Any) -> None:
        """
        设置配置项并立即持久化

        Args:
            key: 配置键名
            value: 配置值
        """
        self._data[key] = value
        self._save()

    def get_api_key(self) -> str:
        """获取 DeepSeek API Key"""
        return self.get("api_key", "")

    def set_api_key(self, key: str) -> None:
        """设置 DeepSeek API Key"""
        self.set("api_key", key)

    def get_custom_prompt(self) -> str:
        """获取自定义提示词"""
        return self.get("custom_prompt", "")

    def set_custom_prompt(self, prompt: str) -> None:
        """设置自定义提示词"""
        self.set("custom_prompt", prompt)

    def get_prompt_mode(self) -> str:
        """获取提示词模式: 'default' 或 'custom'"""
        return self.get("prompt_mode", "default")

    def set_prompt_mode(self, mode: str) -> None:
        """设置提示词模式"""
        if mode in ("default", "custom"):
            self.set("prompt_mode", mode)

    def get_templates(self) -> dict:
        """获取所有自定义检查模板"""
        return self.get("templates", {})

    def save_template(self, name: str, items: list) -> None:
        """
        保存/更新一个检查模板

        Args:
            name: 模板名称
            items: 检查项 ID 列表
        """
        templates = self.get_templates()
        templates[name] = items
        self.set("templates", templates)

    def delete_template(self, name: str) -> bool:
        """
        删除指定模板

        Args:
            name: 模板名称

        Returns:
            是否删除成功
        """
        templates = self.get_templates()
        if name in templates:
            del templates[name]
            self.set("templates", templates)
            return True
        return False

    def should_show_guide(self) -> bool:
        """是否应显示操作指南"""
        return self.get("show_guide", True)

    def set_show_guide(self, show: bool) -> None:
        """设置操作指南显示状态"""
        self.set("show_guide", show)

    def get_os_version(self) -> str:
        """获取用户选择的操作系统版本"""
        return self.get("os_version", "")

    def set_os_version(self, version: str) -> None:
        """设置操作系统版本选择"""
        self.set("os_version", version)

    def reset_to_default(self) -> None:
        """重置所有配置为默认值"""
        self._data = self.DEFAULT_CONFIG.copy()
        self._save()


# 全局单例实例（延迟初始化）
_settings_instance: Optional[SettingsManager] = None


def get_settings(config_dir: str = None) -> SettingsManager:
    """
    获取全局 SettingsManager 单例

    Args:
        config_dir: 配置目录路径，仅在首次调用时需要

    Returns:
        SettingsManager 全局单例
    """
    global _settings_instance
    if _settings_instance is None:
        if config_dir is None:
            config_dir = project_root()
        _settings_instance = SettingsManager(config_dir)
    return _settings_instance
