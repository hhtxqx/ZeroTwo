#!/usr/bin/env bash
# ============================================================
# Zero Two — Linux 安全基线检查 Web 服务（集中式架构下的 agent 节点角色）
#
# 在 Linux 主机上运行本脚本，启动 agent：
#   - 在 Linux 本机通过 shell 执行 22 项等保安全基线检查
#   - 生成 EVA 风格 HTML 报告（含 AI 智能分析与整改建议）
#   - 暴露 REST 接口，供 Windows 主机的「集中式控制台」(central_server.py) 远程调度
#
# 启动：  bash start_linux_web.sh
# 随后到 Windows 主机打开集中式控制台（exe 设置页「启动控制台」或 start_central_web.bat），
# 添加本节点（IP:端口，默认 8080）即可远程发起检查。
# ============================================================

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

# ---- 预检：确认项目文件齐全，避免只拷了 .sh 却缺 core/ 导致困惑 ----
required=(
  core/web/linux_web_server.py
  core/linux_checker.py
  core/report_generator.py
  core/checker.py
  core/ai_analysis_fallback.py
  utils/paths.py
)
missing=0
for f in "${required[@]}"; do
  if [ ! -f "$f" ]; then
    echo "缺失文件: $f  （请连同整个项目目录一起拷贝，不要只拷本脚本）"
    missing=1
  fi
done
if [ "$missing" -ne 0 ]; then
  exit 1
fi

# ---- 选择解释器（纯标准库，Python 3.7+ 即可，无需 pip install） ----
PY=""
if command -v python3 >/dev/null 2>&1; then
  PY=python3
elif command -v python >/dev/null 2>&1; then
  PY=python
else
  echo "未找到 python3 / python，请先安装 Python 3.7+。"
  exit 1
fi

HOST="${HOST:-0.0.0.0}"
PORT="${PORT:-8080}"

echo "Zero Two Linux Web 模块目录: $SCRIPT_DIR"
echo "使用解释器: $($PY --version 2>&1)"
echo "启动参数: --host $HOST --port $PORT"
echo "提示: 本机作为 agent 节点，由 Windows 集中式控制台远程调度。"
echo ""

exec "$PY" core/web/linux_web_server.py --host "$HOST" --port "$PORT"
