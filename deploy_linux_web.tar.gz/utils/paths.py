# -*- coding: utf-8 -*-
"""
路径工具：统一解析「开发模式」与「PyInstaller 打包模式」下的目录位置。

背景
----
PyInstaller 6.x 的 onedir 打包会把依赖与数据文件放到可执行文件同级的
``_internal`` 子目录（运行时 ``sys._MEIPASS`` 指向它）：
    D:/product/ZeroTwo_beta/
        ZeroTwo_beta.exe
        _internal/
            resources/logo.png, background.jpg, startup_video.mp4
            ...（所有 .pyd / 库 / 冻结模块）

而各模块的 ``__file__`` 在打包后会指向 ``_internal/...`` 下的冻结位置，
因此不能再用 ``os.path.dirname(__file__)`` 来定位「项目根 / 可执行文件目录」。

约定
----
- 只读资源（resources/）：打包后实际位于 ``sys._MEIPASS/resources``
- 运行时写入目录（reports/ logs/ config/）：必须位于可执行文件所在目录，
  这样用户数据（报告、日志、设置）才能持久保存、且不被升级覆盖

该模块在开发模式下与原来的 ``os.path.dirname(os.path.dirname(__file__))``
完全等价，因此改动对开发环境无副作用。
"""

import os
import sys


def project_root() -> str:
    """返回项目根目录（开发）或可执行文件所在目录（打包）。

    打包（onedir）模式下 ``sys.executable`` 指向
    ``D:/product/ZeroTwo_beta/ZeroTwo_beta.exe``，其目录即
    ``D:/product/ZeroTwo_beta/``，运行时生成的 reports/logs/config 应放在此处。
    """
    if getattr(sys, "frozen", False):
        return os.path.dirname(os.path.abspath(sys.executable))
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def resource_path(name: str) -> str:
    """返回 ``resources/`` 下某文件的绝对路径，兼容开发与打包两种模式。"""
    if getattr(sys, "_MEIPASS", None):
        # 打包后资源位于 _internal/resources
        return os.path.join(sys._MEIPASS, "resources", name)
    return os.path.join(project_root(), "resources", name)
